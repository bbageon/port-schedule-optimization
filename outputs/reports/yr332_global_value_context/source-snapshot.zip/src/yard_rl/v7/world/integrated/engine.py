"""통합 터미널 이벤트 시뮬레이터 — 다중 YC·본선·이송·레인 (YR-036).

단일 YC sim/engine.py 를 동결하고 순수 프리미티브만 재사용해 조립한 신규 엔진.
핵심: deferred commit(dispatch=예약·완료=스택 커밋 → 진행 중 이동 비관측·누출 0),
4종 자원 lock(ReservationTable), rate/delta 구간 비용 적분, clear-out drain, 결정론.
YR-050: 결정 시점은 SERVE 뿐 아니라 ETA 주도 선제 기회(PRE_ADVICE 한정)로도 열린다 —
wake 스케줄은 provided_eta·결정 지평만 사용(도착 진실 미열람), 술어는 candidates 와 공유.
"""
from __future__ import annotations

import copy
import hashlib

from ..domain.enums import CraneStatus, JobFlow, JobStatus, ServiceMode
from ..domain.models import Container
from ..sim.constraints import ConstraintViolation
from ..sim.kpis import KpiTracker
from ..sim.stack import YardStacks
from ..sim.travel_time import gantry_m, move_container, trolley_m
from .cost import CostAccumulator
from .cranes import CraneFleet
from .ledger import CostCause
from .events import EventKind, EventQueue
from .jobplan import JobPlan, JobRef, Move
from .lane import LaneNetwork
from .reservation import Corridor, Reservation, ReservationTable
from .transfer import TransferFleet
from .vessel import VesselWorkType

from dataclasses import dataclass
from ..contract.schema import CandidateKind
from ..domain.enums import InformationLevel
from .candidates import eta_opportunity
from ...job_index import IndexedJobs, job_ids
from ...dispatch_cache import DispatchCache

_EPS = 1e-9


@dataclass(frozen=True)
class TerminalDecision:
    time: float
    crane_ids: tuple[str, ...]


@dataclass(frozen=True)
class ReviewEpoch:
    """YR-099-b — 외부 조정자(다중블록 브리지)가 예약한 **정확한 결정시점** 도달 신호.

    `sim.review_epochs`(기본 [] = 미사용)에 시각을 넣으면 `run_until_decision` 이 그
    시각으로 시계를 전진시킨 뒤 이 값을 반환한다. 빈 리스트면 분기 자체가 성립하지
    않아 **기존 경로·골든 바이트 동일**(계약: review_epochs 미설정 호출자는 이 타입을
    영원히 못 본다). 용도 = 트럭 gate-in 순간에 재배정 창을 정확히 여는 것(근사 금지).
    """

    time: float


@dataclass(frozen=True)
class CraneAssignment:
    crane_id: str
    action: CandidateKind
    job_ref: JobRef | None = None
    # WAIT 사유 (resolver 판별: NO_FEASIBLE | LOST_CONTENTION) — 경합 이력 집계용 (YR-056)
    yield_reason: str | None = None


@dataclass(frozen=True)
class CommitProjection:
    """dry_run_commit 결과 — resolver 의 joint feasibility 오라클 (commit 과 동일 경로)."""

    plans: dict            # crane_id -> JobPlan (수용된 배정)
    reasons: dict          # crane_id -> reject 코드 (미수용)


class TerminalSimulator:
    def __init__(self, profile, scenario, *, check_invariants: bool = True,
                 info_level: InformationLevel = InformationLevel.BLOCK_ARRIVAL,
                 enable_cost_ledger: bool = False,
                 yard_handover_cap: int | None = None):
        self.profile = profile
        self.scenario = scenario
        self._check = check_invariants
        self.info_level = info_level     # PRE_REHANDLE/REPOSITION 정보시점 게이팅 (YR-037)
        self._enable_ledger = enable_cost_ledger   # 비용 인과 ledger (기본 off → golden 불변, YR-038)
        # YR-088 파생: 양하 인계버퍼 역압력 (opt-in). None(기본)=현행(이송 도착 시 quay 버퍼
        # 해제·YC 적재 지연이 STS 에 역압력 안 감) = 골든 바이트 동일. int 면 STS-뽑기~YC-적재
        # 사이 미완 양하 박스를 그 수로 제한 → YC 가 늦으면 STS 가 막힌다(양하 결정권 부여).
        if yard_handover_cap is not None and (
                isinstance(yard_handover_cap, bool)
                or not isinstance(yard_handover_cap, int) or yard_handover_cap <= 0):
            raise ValueError("yard_handover_cap must be a positive integer or None")
        self.yard_handover_cap = yard_handover_cap
        # YR-099-b: 외부 조정자가 예약하는 정확 결정시점(오름차순). 기본 [] = 골든 불변.
        self.review_epochs: list[float] = []
        self.reset()

    # ------------------------------------------------------------- lifecycle
    def reset(self):
        self._validate()
        geom = self.profile.block
        self.stacks = YardStacks(geom, copy.deepcopy(self.scenario.containers))
        self.jobs = IndexedJobs((j.job_id, copy.deepcopy(j)) for j in self.scenario.jobs)
        self.dispatch_cache = DispatchCache()
        self.fleet = CraneFleet()
        for spec in self.profile.cranes:
            self.fleet.add(spec, geom.transfer_row)
        self.reservations = ReservationTable(self.profile.safety_gap_bay)
        # YR-091(외부감사 결함2): ①초기 위치 — 같은 담당구간(공유 레일 구간) 크레인들을
        # id 순서 = 물리 순서로 등간격 분산 (이전엔 전부 service_bay_min 동일 시작 = 간격 0).
        # ②예약 없는 크레인 현재 위치를 상시 장벽으로 등록 (비통과 레일 물리).
        groups: dict[tuple[int, int], list[str]] = {}
        for cid in self.fleet.ids():
            sp = self.fleet.spec(cid)
            groups.setdefault((sp.service_bay_min, sp.service_bay_max), []).append(cid)
        for (lo, hi), ids in groups.items():
            n = len(ids)
            if n > 1:
                for k, cid in enumerate(ids):                     # id 순 = 물리 순
                    self.fleet.get(cid).state.position_bay = lo + (k + 0.5) * (hi - lo) / n
        for cid in self.fleet.ids():
            self.reservations.set_idle_position(cid, self.fleet.get(cid).state.position_bay)
        # 물리(레일) 순서 = 초기 bay 오름차순 (tie=id) — 비통과 불변식의 기준 순서
        self._rail_order: tuple[str, ...] = tuple(sorted(
            self.fleet.ids(), key=lambda c: (self.fleet.get(c).state.position_bay, c)))
        from .ledger import CostLedger
        self.cost = CostAccumulator(ledger=CostLedger() if self._enable_ledger else None)
        self.kpis = KpiTracker(sla_s=self.profile.long_wait_sla_s)
        # YR-089 시간계약 v2 — 시나리오가 v2 필드(exit_travel_s)로 생성됐을 때만 장부 활성.
        # v1 시나리오는 None = 기존 비용·이벤트 경로 바이트 동일 (골든 안전). 장부는 비용·KPI
        # 정산 전용(GROUND_TRUTH) — 정책 입력 아님. A(진입)·O(출문)는 이벤트 큐에 넣지 않고
        # 장부가 구간적분 중 경계 처리 → event_log 불변·YC 결정시점 미개방 (계약).
        from .time_contract import TimeLedger
        _v2 = [j for j in self.jobs.values()
               if j.is_external_truck and j.exit_travel_s is not None]
        self.time_ledger = TimeLedger(sla_s=self.profile.long_wait_sla_s) if _v2 else None
        if self.time_ledger is not None:
            for j in sorted(_v2, key=lambda x: x.job_id):
                self.time_ledger.register(j.job_id, j.actual_gate_in or 0.0)
            self.time_ledger.seal()
        self.transfer = TransferFleet(
            self.profile.transfer.fleet_id, self.profile.transfer.kind,
            self.profile.transfer.n_units, self.profile.transfer.move_time_s)
        self.lanes = LaneNetwork(self.profile.lane_graph)
        self.vessels = {v.vessel_id: copy.deepcopy(v) for v in self.scenario.vessels}
        # YR-088: 양하 인계 파이프라인 (vessel_id→미완 적재 박스 수) — yard_handover_cap None 이면
        # 미사용(빈 dict). VesselProcess 스키마 불변 유지 위해 sim 레벨로 둔다(골든 안전).
        self._discharge_pipeline: dict[str, int] = {}
        self.queue = EventQueue()
        self.clock = 0.0
        self.end = self.scenario.end_time
        self._terminal = False
        self._pending: tuple[str, ...] = ()
        # YR-075-a: 재조작 목적지 선택 훅 (opt-in). None(기본)이면 stk.find_slot greedy
        # 그대로 = 골든 바이트 동일. 설정 시 selector(sim, stk, blocker, spec, exclude)
        # → (bay,row)|None. 평가 오라클·후보 확장이 재사용 (rollout deepcopy 보존).
        self.slot_selector = getattr(self, "slot_selector", None)
        # YR-080 단계6: 신규 적재(STORE — 트럭 반입·본선 양하) 위치 선택 훅 (opt-in).
        # None(기본)이면 find_slot greedy 그대로 = 골든 바이트 동일. 설정 시
        # selector(sim, stk, job, spec, bay, row, exclude) → (bay,row)|None.
        self.store_slot_selector = getattr(self, "store_slot_selector", None)
        self._assigned: dict[str, CraneAssignment] = {}
        self._active_plans: dict[str, JobPlan] = {}
        self.event_log: list[tuple[float, str, str]] = []
        self.resolution_log: list = []       # JointResolution (YR-037, 계약 밖 side-channel)
        # YR-050 ETA wake 스케줄 — 외부 반출트럭 provided_eta 가 결정 지평에 들어오는 시각.
        # actual_* 은 절대 읽지 않는다(누출 0). queue 이벤트가 아니라 데이터로 두고
        # run_until_decision 이 PRE_ADVICE 일 때만 소비 → 낮은 정보수준의 이벤트 스트림·
        # golden 은 불변이고, info_level 을 reset 후에 바꿔도(record_episode) 정상 동작한다.
        # GATE_OUT 한정: 선제 재조작 기회(eta_opportunity)는 반출 대상에서만 생기므로
        # GATE_IN wake 는 항상 no-op — 시드하지 않는다.
        horizon = self.profile.decision_horizon_s
        self._eta_wakes: list[tuple[float, str]] = sorted(
            (max(0.0, j.provided_eta - horizon), j.job_id)
            for j in self.scenario.jobs
            if j.flow == JobFlow.GATE_OUT and j.target_container is not None
            and j.provided_eta is not None
            and max(0.0, j.provided_eta - horizon) < self.end)
        self._wake_idx = 0
        # wake 1회당 크레인별 1회 질문(armed) — 기회가 잔존하는 동안 모든 이벤트가 결정을
        # 재개방하면 WAIT-최하위 baseline 이 REPOSITION 을 반복 선택하는 되먹임(결정 464건·
        # REPO 88% 실측)이 생긴다. 거절한 크레인은 다음 wake 까지 선제 전용 결정을 안 연다.
        # SERVE 주도 결정에서는 PRE 후보가 기존(YR-048)대로 계속 발행된다.
        self._eta_armed: set[str] = set()
        # YR-147 opt-in — 유한 DEFER 만료·trigger 재개방 예약 (기본 미사용 = 골든 불변)
        self._defer_wakes: list[float] = []
        # YR-112: 간섭 교착 탈출을 같은 시각에 두 번 열지 않기 위한 표식 (무한루프 방지)
        self._escape_at: float | None = None
        self._escape_count: int = 0
        # YR-050 계약(결정 시각 엄격 증가) 준수를 위한 마지막 결정 시각
        self._last_decision_at: float | None = None
        # YR-112-b 탈출 시점 **계약 확정 (2026-07-28, 실측 근거)**
        #   "immediate"(정본) — 교착이 성립하는 **즉시** 결정을 연다.
        #   "delayed"        — 엔진이 포기하려는 마지막 순간에만 연다(초판·비교군).
        # 근거: 교착은 "어떤 크레인도 아무것도 못 하고 **정책은 질문조차 받지 못한** 상태"다.
        # 그 사이의 유휴는 정책의 선택이 아니라 결정의 부재이므로, 시뮬레이터가 만들어낸
        # 인공 유휴다(대기비용이 그동안 계속 쌓인다). 실측:
        #   · 기존 판정 대역 32런 — 즉시 모드 발화 **0회**, 런 해시 **전부 동일** (골든 안전)
        #   · 신규 대역 96런 — 지연 2회 vs 즉시 7회 → 지연은 교착 5건을 "기다려서" 넘긴다
        # 즉 즉시 모드는 과거 판정을 하나도 바꾸지 않으면서 인공 유휴만 제거한다.
        self.escape_mode: str = "immediate"
        self._seed_events()
        self._refresh_rates()

    def _validate(self):
        geom = self.profile.block
        occupied: set[tuple[int, int, int]] = set()
        for c in self.scenario.containers.values():
            if not (1 <= c.bay <= geom.bay_count and 1 <= c.row <= geom.row_count
                    and 1 <= c.tier <= geom.tier_max):
                raise ConstraintViolation("INVALID_SLOT", f"{c.container_id} 슬롯 범위 밖")
            slot = (c.bay, c.row, c.tier)
            if slot in occupied:
                raise ConstraintViolation("DUPLICATE_EVENT", f"슬롯 중복 {slot}")
            occupied.add(slot)
        for (b, r, t) in occupied:
            if t > 1 and (b, r, t - 1) not in occupied:
                raise ConstraintViolation("FLOATING_CONTAINER", f"({b},{r},{t}) 아래 빔")
        # YR-092(외부감사 결함3): 초기상태도 실행 적재규칙(pile 동일규격) 준수 — 위반 시 거부.
        pile_sizes: dict[tuple[int, int], object] = {}
        for c in self.scenario.containers.values():
            prev = pile_sizes.setdefault((c.bay, c.row), c.size)
            if prev != c.size:
                raise ConstraintViolation(
                    "PILE_SIZE_MIX", f"({c.bay},{c.row}) 혼합규격 초기 pile — 실행규칙 위반")
        for j in self.jobs_input():
            if j.target_container is not None and j.target_container not in self.scenario.containers:
                raise ConstraintViolation("UNMATCHED_JOB", f"{j.job_id} 대상 부재")

    def jobs_input(self):
        return self.scenario.jobs

    def _seed_events(self):
        for j in sorted(self.scenario.jobs, key=lambda x: x.job_id):
            if j.is_external_truck:
                self.queue.push(j.actual_block_arrival, EventKind.BLOCK_ARRIVAL, j.job_id)
            else:
                # YR-080 단계2: 양하(STORE) job 은 시간 해제가 아니라 박스의 물리 도착
                # (STS→이송→TRANSFER_ARRIVE→VESSEL_RELEASED)으로 해제 — 인과 사슬 양하 절반.
                if j.is_vessel_linked and j.service_mode == ServiceMode.STORE:
                    continue
                self.queue.push(j.release_time, EventKind.JOB_RELEASED, j.job_id)
        for v in sorted(self.scenario.vessels, key=lambda x: x.vessel_id):
            self.queue.push(v.plan.planned_start_s, EventKind.VESSEL_START, v.vessel_id)
        for ie in sorted(self.scenario.injected_events, key=lambda x: (x.time, x.kind, x.target)):
            kind = {"EQUIPMENT_DOWN": EventKind.EQUIPMENT_DOWN,
                    "EQUIPMENT_UP": EventKind.EQUIPMENT_UP,
                    "PLAN_CHANGE": EventKind.PLAN_CHANGE}[ie.kind]
            self.queue.push(ie.time, kind, ie.target, data=ie.data)
        self.queue.push(self.scenario.horizon_s, EventKind.HORIZON, "HORIZON")

    # ------------------------------------------------------------- queries
    @property
    def now(self) -> float:
        return self.clock

    @property
    def terminal(self) -> bool:
        return self._terminal

    def observable_stacks(self) -> YardStacks:
        """정책 관측용 — 커밋된 스택만 (진행 중 이동 미반영)."""
        return self.stacks

    def cum_wait(self, job_id: str) -> float:
        """트럭 진실 누적대기 (realized_at 게이팅·비용 전용 — feature 값 아님)."""
        j = self.jobs.get(job_id)
        if j is None or not j.is_external_truck or j.actual_block_arrival is None:
            return 0.0
        if j.actual_block_arrival > self.clock:
            return 0.0
        return self.clock - j.actual_block_arrival

    def eligible_cranes(self, bay: int) -> tuple[str, ...]:
        return tuple(cid for cid in self.fleet.ids()
                     if self.fleet.spec(cid).service_bay_min <= bay <= self.fleet.spec(cid).service_bay_max)

    def _lane_for(self, bay: int) -> str | None:
        ids = self.profile.lane_graph.lane_ids
        return ids[(bay - 1) % len(ids)] if ids else None

    # ------------------------------------------------------------- main loop
    def run_until_decision(self) -> TerminalDecision | None:
        if self._pending:
            raise RuntimeError("직전 결정 미해소 — close_decision 먼저")
        while True:
            if self._terminal:
                return None
            raw_nt = self.queue.peek_time()
            # YR-089 정정(외부감사 결함1): 평가창(end) 밖 이벤트는 처리하지 않는다.
            # 비용 적분은 end 에서 잘리는데 완료·완주율은 그 뒤까지 반영되던 시간창 불일치
            # (포화 셀에서 "완주 100%·backlog 0·최종시계 241.61s>end=100s" 실측) 제거 —
            # end 시점 RUNNING 작업은 미완료(검열 표본·backlog)로 남는다.
            nt = raw_nt if (raw_nt is None or raw_nt <= self.end + _EPS) else None
            if nt is not None and nt <= self.clock + _EPS:
                self._process_next_event()
                continue
            if self._consume_due_wakes():   # YR-050: 동시각 이벤트 처리 후·결정 판정 전
                continue
            idle = self._decision_cranes()
            if idle and self.clock < self.end - _EPS:
                self._pending = idle
                self._assigned = {}
                self._eta_armed -= set(idle)   # 결정에 포함 = 이번 wake 의 질문 소진
                self._last_decision_at = self.clock
                return TerminalDecision(self.clock, idle)
            # YR-112 계약 A(즉시): 교착이면 **미래 이벤트를 기다리지 않고** 지금 연다.
            # 계약 B(지연)는 아래 `_finalize` 직전에서만 연다. 기본값은 escape_mode 로 고정.
            if self.escape_mode == "immediate":
                esc = self._try_escape()
                if esc is not None:
                    return esc
            wt = self._next_wake_time()
            if wt is not None and wt > self.end + _EPS:   # wake 도 평가창 밖이면 시계 전진 금지
                wt = None
            # YR-099-b: 예약된 review epoch 은 **현재 시각의 결정·wake 를 모두 소진한 뒤**,
            # 다음 이벤트·wake 보다 이를 때만 그 시각으로 전진하고 제어를 반환한다.
            # (적대검증 critical-1 정정: 이 분기가 결정 판정보다 위에 있으면 지금 열려야 할
            #  결정을 선점해 크레인을 놀리고 기준선 비용이 24~32% 부풀었다. wt 와도 경쟁시켜
            #  건너뛴 ETA wake 가 밀리는 부작용까지 제거 — 이송 0건이면 런이 바이트 동일.)
            while self.review_epochs and self.review_epochs[0] > self.end + _EPS:
                self.review_epochs.clear()
            if self.review_epochs:
                ep = self.review_epochs[0]
                if (nt is None or ep <= nt + _EPS) and (wt is None or ep <= wt + _EPS):
                    self.review_epochs.pop(0)
                    if ep > self.clock + _EPS:
                        self._advance(ep)
                    return ReviewEpoch(self.clock)
            if nt is None and wt is None:
                if raw_nt is None and any(c.state.assigned_job for c in self.fleet.all()):
                    raise RuntimeError("작업 중인데 완료 이벤트 없음 — 엔진 버그")
                # YR-112 계약 B(지연): 마지막 순간에만 연다. immediate 모드면 이미 위에서
                # 처리됐으므로 여기서는 중복 발화하지 않는다(같은 시각 표식이 막는다).
                esc = self._try_escape()
                if esc is not None:
                    return esc
                self._finalize()
                return None
            if wt is not None and (nt is None or wt < nt - _EPS):
                self._advance(wt)           # 이벤트 없는 구간의 시계 전진 — 다음 순회에서 소비
                continue
            self._process_next_event()

    # ------------------------------------------------------ ETA wake (YR-050)
    def schedule_defer_wake(self, t: float) -> None:
        """YR-147: 유한 DEFER 의 만료·trigger 시각 재개방 예약 (opt-in).

        기존 WAIT 계약(무기한)에서는 아무도 호출하지 않아 골든 불변. 과거·평가창 밖
        시각은 무시(창 밖 시계 전진 금지 계약과 정합)."""
        if t > self.clock + _EPS and t <= self.end + _EPS:
            from bisect import insort
            insort(self._defer_wakes, t)

    def _next_wake_time(self) -> float | None:
        """미소비 wake 의 최소 시각 — ETA wake 는 PRE_ADVICE 한정, DEFER wake 는
        정보수준 무관(opt-in 예약이 있을 때만 존재)."""
        dw = self._defer_wakes[0] if self._defer_wakes else None
        if self.info_level != InformationLevel.PRE_ADVICE:
            return dw
        if self._wake_idx >= len(self._eta_wakes):
            return dw
        et = self._eta_wakes[self._wake_idx][0]
        return et if dw is None else min(et, dw)

    def _consume_due_wakes(self) -> bool:
        """현재 시각 도래 wake 를 전부 소비 — 전 크레인 arm + yield 해제로 결정 평가를 연다.

        wake 는 1회성(같은 시각 무한 WAIT 재결정 없음). arm 은 크레인이 결정에 한 번
        포함되면 소진 — 그 사이 바쁜 크레인은 armed 를 유지해 놓친 wake 를 유휴화 시점에
        받는다. 소비는 event_log 에 남아 PRE_ADVICE 의 event_stream_hash 에 가시화된다.
        DEFER wake(YR-147)는 같은 소비 계약을 따르며 예약이 없으면 완전 무비용.
        """
        fired = False
        while self._defer_wakes and self._defer_wakes[0] <= self.clock + _EPS:
            self._defer_wakes.pop(0)
            self.event_log.append((self.clock, "DEFER_WAKE", ""))
            fired = True
        if self.info_level == InformationLevel.PRE_ADVICE:
            while (self._wake_idx < len(self._eta_wakes)
                   and self._eta_wakes[self._wake_idx][0] <= self.clock + _EPS):
                _, jid = self._eta_wakes[self._wake_idx]
                self._wake_idx += 1
                self.event_log.append((self.clock, "ETA_WAKE", jid))
                fired = True
        if fired:
            self._eta_armed = set(self.fleet.ids())
            self._clear_yields()
        return fired

    def _try_escape(self) -> "TerminalDecision | None":
        """YR-112 간섭 교착 탈출 결정 — 조건 충족 시 유휴 크레인 전원에게 결정을 연다.

        물리(유휴 크레인 관통 금지, YR-091)는 옳으므로 **결정 기회만** 연다. 같은 시각
        재개방은 표식으로 막는다(정책이 계속 WAIT 해도 무한루프가 되지 않는다).
        """
        if self.clock >= self.end - _EPS or self._escape_at == self.clock:
            return None
        # YR-050 계약 준수: **결정 시각은 엄격히 증가**한다(wake 1회성). 이미 이 시각에
        # 결정을 열었다면 정책은 이미 답을 했다 — 같은 시각 재질문은 그 계약 위반이다.
        # (탈출은 다음 시각으로 미뤄진다. 실측상 교착 해소에는 영향이 없다.)
        if self._last_decision_at is not None and self.clock <= self._last_decision_at + _EPS:
            return None
        if not self.interference_deadlock_corridors():
            return None
        self._clear_yields()
        esc = tuple(c.crane_id for c in self.fleet.all() if c.idle)
        if not esc:
            return None
        self._escape_at = self.clock
        self._last_decision_at = self.clock
        self._escape_count += 1
        self._pending = esc
        self._assigned = {}
        self.event_log.append((self.clock, "DEADLOCK_ESCAPE", ",".join(esc)))
        return TerminalDecision(self.clock, esc)

    @property
    def deadlock_escape_count(self) -> int:
        """YR-112 발화 횟수 — 실험 arm 마다 저장해 **탈출이 결과에 개입했는지** 감사한다."""
        return self._escape_count

    def interference_deadlock_corridors(self) -> tuple[tuple[float, float], ...]:
        """YR-112 활성 결함 술어 — **후보 생성기와 공유**한다 (eta_opportunity 관습).

        조건 셋을 모두 만족할 때만 참이다 (그래서 정상 런에는 절대 발화하지 않는다):
          ① 진행 중인 작업이 없다 (모든 크레인 유휴)
          ② 어떤 크레인에도 실행가능한 SERVE 후보가 없다
          ③ 그런데 배차 가능한 작업이 있고, 그 거절 사유가 **오직 크레인 간섭**이다

        반환: 막힌 작업들의 **통로 구간**(lo, hi). 대상 bay 하나가 아니라 구간을 주는 이유 —
        재조작이 끼면 통로가 여러 bay 에 걸치고(실측 (17,19)), 그때 막는 크레인이 물러나야 할
        거리는 구간의 **가까운 끝** 기준이라야 맞다(bay 하나만 보면 안 움직여도 된다고 잘못 계산).
        """
        if any(c.state.assigned_job for c in self.fleet.all()):
            return ()
        if any(self.candidates_for(cid) for cid in self.fleet.ids()):
            return ()
        cors: list[tuple[float, float]] = []
        for jid in sorted(self.jobs):
            j = self.jobs[jid]
            if self.reservations.job_taken(j.job_id) is not None:
                continue
            for cid in self.fleet.ids():
                if not self._dispatchable(j, cid):
                    continue
                yc, spec = self.fleet.get(cid), self.fleet.spec(cid)
                ref = self._jobref(j, spec, yc)
                if ref is None:
                    continue
                plan = self._plan(cid, ref)
                if plan is None:
                    continue
                if self.reservations.reject_reason(
                        self._reservation(plan)) == "CRANE_INTERFERENCE":
                    cors.append((float(plan.corridor[0]), float(plan.corridor[1])))
                    break
        return tuple(sorted(set(cors)))

    def _decision_cranes(self) -> tuple[str, ...]:
        out = []
        for yc in self.fleet.all():
            if not yc.idle or yc.yielded:
                continue
            # SERVE 실행가능(전 정보수준). ETA 주도 선제 기회(PRE_ADVICE 한정, YR-050)는
            # wake 로 armed 된 크레인만 연다 — 술어는 후보 생성기와 공유(어긋남 차단).
            first = (getattr(self, 'decision_probe_shortcircuit', False)
                     and self.slot_selector is None and self.store_slot_selector is None)
            if (self.candidates_for(yc.crane_id, first_only=first)
                    or (yc.crane_id in self._eta_armed
                        and eta_opportunity(self, yc.crane_id, self.info_level))):
                out.append(yc.crane_id)
        return tuple(out)

    # ------------------------------------------------------------- candidates
    def candidates_for(self, crane_id: str, *, first_only=False) -> list[JobRef]:
        """이 크레인이 지금 실행 가능하고 예약 성공하는 SERVE 후보 (결정론 정렬).

        YR-037 이 mandatory 보존·pruning·pre-rehandle 로 교체할 seam. 여기서는 최소 열거.
        """
        yc = self.fleet.get(crane_id)
        if not yc.idle or yc.yielded:
            return []
        spec = self.fleet.spec(crane_id)
        out: list[JobRef] = []
        for jid in job_ids(self, JobStatus.WAITING, JobStatus.RELEASED):
            j = self.jobs[jid]
            if not self._dispatchable(j, crane_id):
                continue
            if self.reservations.job_taken(j.job_id) is not None:
                continue
            ref = self._jobref(j, spec, yc)
            if ref is None:
                continue
            plan = self._plan(crane_id, ref)
            if plan is None:
                continue
            if not self.reservations.can_reserve(self._reservation(plan)):
                continue
            out.append(ref)
            if first_only:
                break
        return out

    def _dispatchable(self, j, crane_id: str) -> bool:
        if j.status not in (JobStatus.WAITING, JobStatus.RELEASED):
            return False
        if j.assigned_crane is not None:
            return False
        spec = self.fleet.spec(crane_id)
        if j.target_container is not None:
            c = self.stacks.containers.get(j.target_container)
            if c is None or not c.work_available:
                return False
            if not (spec.service_bay_min <= c.bay <= spec.service_bay_max):
                return False
            if not self.stacks.rehandle_capacity_ok(j.target_container, spec):
                return False
        if j.service_mode == ServiceMode.STORE:      # 신규 반입 — 적재 슬롯 필요 (YR-080 §1)
            yc = self.fleet.get(crane_id)
            if self._store_slot(j, spec, yc.state.position_bay,
                                yc.state.trolley_row) is None:
                return False
        return True

    def _store_slot(self, j, spec, bay, row, exclude=frozenset()):
        """신규 적재(STORE) 슬롯 — opt-in 훅 (YR-080 단계6, seam 3곳 일관 적용).

        None(기본) = find_slot greedy 그대로 (골든 불변). 훅 반환은 find_slot 후조건과
        동일해야 하며 위반 시 즉시 발화 (조용한 물리 불일치 계획 방지 — 재조작 seam 관습).
        """
        if self.store_slot_selector is None:
            key = (j.inbound_size, spec, bay, row, frozenset(exclude))
            return self.dispatch_cache.slot(key, lambda: self.stacks.find_slot(
                j.inbound_size, spec, bay, row, exclude=frozenset(exclude)))
        dest = self.store_slot_selector(self, self.stacks, j, spec, bay, row,
                                        frozenset(exclude))
        if dest is not None:
            db, dr = dest
            if (dest in exclude
                    or not (spec.service_bay_min <= db <= spec.service_bay_max)
                    or self.stacks.top_tier(db, dr) + 1 > self.profile.block.tier_max
                    or not self.stacks.stack_size_ok(db, dr, j.inbound_size)):
                raise RuntimeError(f"store_slot_selector 후조건 위반 ({db},{dr})")
        return dest

    def _jobref(self, j, spec, yc) -> JobRef | None:
        if j.target_container is not None:
            bay = self.stacks.containers[j.target_container].bay
        elif j.service_mode == ServiceMode.STORE:
            slot = self._store_slot(j, spec, yc.state.position_bay,
                                    yc.state.trolley_row)
            if slot is None:
                return None
            bay = slot[0]
        else:
            return None
        return JobRef(job_id=j.job_id, token=j.job_id, kind=CandidateKind.SERVE,
                      target_container=j.target_container, lane_id=self._lane_for(bay),
                      eligible_crane_ids=self.eligible_cranes(bay),
                      is_vessel=j.is_vessel_linked, is_external=j.is_external_truck)

    # ------------------------------------------------------------- planning
    def _plan(self, crane_id: str, ref: JobRef, *, extra_exclude=frozenset()) -> JobPlan | None:
        """스택 미변형으로 JobPlan 계산 (deferred). 실패 시 None.

        kind 분기: SERVE(GATE_IN 장치 / GATE_OUT·본선 반출) · PRE_REHANDLE(blocker 만 relocate,
        target 잔존) · REPOSITION(컨테이너 미조작, 빈 주행만). extra_exclude 는 dry_run 순차 예약.
        """
        yc = self.fleet.get(crane_id)
        spec = self.fleet.spec(crane_id)
        geom = self.profile.block
        cur_bay, cur_row = yc.state.position_bay, yc.state.trolley_row

        if ref.kind == CandidateKind.REPOSITION:
            tb = ref.reposition_target_bay
            if tb is None:
                return None
            tb = float(min(max(tb, spec.service_bay_min), spec.service_bay_max))
            dist = gantry_m(geom, cur_bay, tb)
            t_dist = trolley_m(geom, cur_row, geom.transfer_row)
            dur = dist / spec.gantry_speed_mps + t_dist / spec.trolley_speed_mps
            return JobPlan(crane_id=crane_id, job_id=ref.job_id, token=None,
                           kind=CandidateKind.REPOSITION, moves=(),
                           corridor=(min(cur_bay, tb), max(cur_bay, tb)), slots=frozenset(),
                           lane_id=None, start_s=self.clock, duration_s=dur, end_bay=tb,
                           end_row=float(geom.transfer_row), rehandles=0,
                           loaded_gantry_m=0.0, empty_gantry_m=dist)

        # YR-047: 가상 진행의 격리는 exclude 집합이 운반한다 — 각 blocker 의 목적지는 배치 즉시
        # exclude 에 들어가고, 원천 스택(대상과 같은 pile)은 호출마다 제외되므로, find_slot/
        # top_tier 는 가상으로 변형된 스택을 다시 읽지 않는다. 따라서 스택 전체 deepcopy 없이
        # 원본을 읽기 전용으로 써도 SERVE/REPOSITION 은 결과 동일 (등가성: test_plan_no_deepcopy.py).
        # 단 PRE_REHANDLE 의 slots·corridor 는 **의도적으로 구버전과 다르다**: 구버전은 place() 가
        # b.bay/b.row 를 목적지로 덮어쓴 '뒤' 장부를 기록하는 별칭(aliasing) 버그로 원천 pile 을
        # 예약에서 누락했다(과소예약 — SERVE 는 target 반출이 같은 pile 을 재추가해 우연히 은폐).
        # 신버전은 원천 pile 도 slots·corridor 에 포함한다 — 크레인이 실제로 주행·조작하는 범위.
        # stk 를 변형하는 호출(remove/place)을 추가하면 격리 전제가 깨진다 — 금지.
        stk = self.stacks
        exclude = set(self.reservations.reserved_slots()) | set(extra_exclude)
        moves: list[Move] = []
        touched_bays = {cur_bay}
        slots: set[tuple[int, int]] = set()
        total_s = loaded_m = empty_m = 0.0
        rehandles = 0
        j = self.jobs[ref.job_id]

        if j.service_mode == ServiceMode.STORE and ref.kind == CandidateKind.SERVE:
            dest = self._store_slot(j, spec, cur_bay, cur_row, exclude=exclude)
            if dest is None:
                return None
            db, dr = dest
            dtier = stk.top_tier(db, dr) + 1
            src = (db, geom.transfer_row, 1)
            mv = move_container(spec, geom, cur_bay, cur_row, src, (db, dr, dtier))
            inbound = Container(container_id=f"IN_{j.job_id}", size=j.inbound_size,
                                load_status=j.inbound_load, block=geom.block_id,
                                bay=db, row=dr, tier=dtier)
            moves.append(Move(inbound.container_id, src, (db, dr, dtier),
                              mv.loaded_gantry_m, mv.empty_gantry_m, mv.duration_s, inbound=inbound))
            total_s += mv.duration_s
            if j.is_external_truck:      # 본선 양하는 트럭 위치잡기 없음 (인계 0초 — 단계0 결정)
                total_s += spec.truck_positioning_time_s
            loaded_m += mv.loaded_gantry_m
            empty_m += mv.empty_gantry_m
            cur_bay, cur_row = mv.end_bay, mv.end_row
            touched_bays |= {db}
            slots.add((db, dr))
        else:
            target_id = j.target_container
            for blocker_id in stk.blockers_above(target_id):
                b = stk.containers[blocker_id]
                src = (b.bay, b.row, b.tier)
                excl = frozenset(exclude | {(b.bay, b.row)})
                if self.slot_selector is not None:      # YR-075-a opt-in (오라클/후보)
                    dest = self.slot_selector(self, stk, b, spec, excl)
                elif self.dispatch_cache.rehandle_slots:
                    dest = self.dispatch_cache.rehandle_slot(
                        stk, b.size, spec, float(b.bay), float(b.row), excl)
                else:
                    dest = stk.find_slot(b.size, spec, float(b.bay), float(b.row), exclude=excl)
                if dest is None:
                    return None
                db, dr = dest
                dtier = stk.top_tier(db, dr) + 1
                # 구 place() 검증 승계 + exclude 계약 가드 — 위의 격리 전제가 기대는 후조건이므로
                # find_slot 이 변경되면 여기서 즉시 발화해야 한다 (조용한 물리 불일치 계획 방지).
                if (dtier > geom.tier_max or not stk.stack_size_ok(db, dr, b.size)
                        or dest in exclude or dest == (b.bay, b.row)):
                    raise RuntimeError(f"({db},{dr}) find_slot 후조건 위반")
                mv = move_container(spec, geom, cur_bay, cur_row, src, (db, dr, dtier))
                moves.append(Move(blocker_id, src, (db, dr, dtier),
                                  mv.loaded_gantry_m, mv.empty_gantry_m, mv.duration_s))
                total_s += mv.duration_s
                loaded_m += mv.loaded_gantry_m
                empty_m += mv.empty_gantry_m
                cur_bay, cur_row = mv.end_bay, mv.end_row
                rehandles += 1
                exclude.add((db, dr))
                touched_bays |= {b.bay, db}
                slots |= {(b.bay, b.row), (db, dr)}
            if ref.kind == CandidateKind.SERVE:
                # 대상 반출 (PRE_REHANDLE 은 blocker 만 치우고 target 잔존)
                target = stk.containers[target_id]
                src = (target.bay, target.row, target.tier)
                dst = (target.bay, geom.transfer_row, 1)
                mv = move_container(spec, geom, cur_bay, cur_row, src, dst)
                moves.append(Move(target_id, src, dst, mv.loaded_gantry_m, mv.empty_gantry_m,
                                  mv.duration_s, depart=True))
                total_s += mv.duration_s
                if j.is_external_truck:
                    total_s += spec.truck_positioning_time_s
                loaded_m += mv.loaded_gantry_m
                empty_m += mv.empty_gantry_m
                cur_bay, cur_row = mv.end_bay, mv.end_row
                touched_bays |= {target.bay}
                slots.add((target.bay, target.row))

        lo, hi = min(touched_bays), max(touched_bays)
        return JobPlan(crane_id=crane_id, job_id=j.job_id, token=ref.token, kind=ref.kind,
                       moves=tuple(moves), corridor=(lo, hi), slots=frozenset(slots),
                       lane_id=ref.lane_id, start_s=self.clock, duration_s=total_s,
                       end_bay=cur_bay, end_row=cur_row, rehandles=rehandles,
                       loaded_gantry_m=loaded_m, empty_gantry_m=empty_m)

    def _reservation(self, plan: JobPlan) -> Reservation:
        return Reservation(crane_id=plan.crane_id, job_token=plan.token,
                           corridor=Corridor(plan.corridor[0], plan.corridor[1]),
                           slots=plan.slots, lane_id=plan.lane_id,
                           release_at=plan.start_s + plan.duration_s)

    # ------------------------------------------------------------- decision commit
    def assign(self, crane_id: str, assignment: CraneAssignment) -> None:
        if crane_id not in self._pending:
            raise ConstraintViolation("DECISION_COVERAGE", f"{crane_id} 결정 대상 아님")
        if crane_id in self._assigned:
            raise ConstraintViolation("DECISION_COVERAGE", f"{crane_id} 이미 배정")
        yc = self.fleet.get(crane_id)
        if assignment.action == CandidateKind.WAIT:
            yc.yielded = True
            if assignment.yield_reason == "LOST_CONTENTION":
                yc.recent_yield_count += 1     # 경합 이력 (COORD feature, YR-056)
            self._assigned[crane_id] = assignment
            return
        ref = assignment.job_ref
        if ref is None:
            raise ConstraintViolation("BAD_ASSIGN", f"{crane_id} {assignment.action.value} 인데 job 없음")
        plan = self._plan(crane_id, ref)
        if plan is None:
            raise ConstraintViolation("NOT_DISPATCHABLE", f"{crane_id}:{ref.job_id} 계획 불가")
        self.reservations.reserve(self._reservation(plan))   # 2차 방어선
        self._active_plans[crane_id] = plan
        yc.state.assigned_job = plan.job_id
        yc.state.status = CraneStatus.HANDLING
        yc.state.available_at = plan.start_s + plan.duration_s
        yc.is_loaded = assignment.action != CandidateKind.REPOSITION
        # SERVE 만 job 을 RUNNING 으로 (PRE_REHANDLE 은 대상 job 을 서비스하지 않음 — PLANNED 잔존,
        # 동시 SERVE 는 token 예약이 차단). REPOSITION 은 job 없음.
        if assignment.action == CandidateKind.SERVE:
            j = self.jobs[plan.job_id]
            j.status = JobStatus.RUNNING
            j.assigned_crane = crane_id
            j.service_start = self.clock
            if j.is_external_truck:   # 서비스 시작 = dispatch 시점 (대기 적분 종료, engine.py:185)
                self.kpis.service_started(j.job_id, self.clock)
                if self.time_ledger is not None:        # YR-089 v2: S 기록 (블록 점유는 C 까지)
                    self.time_ledger.service_start(j.job_id, self.clock)
                link = getattr(j, 'visit_link', None)
                if link is not None:
                    # [[YR-332-al]] Completion is fixed at dispatch. The terminal releases the
                    # truck's next stop (or fixes its single exit) from this time.
                    self.__dict__.setdefault('visit_outbox', []).append(
                        (link['id'], link['stop'], j.job_id, plan.start_s + plan.duration_s))
        self.cost.accrue("crane_travel", plan.loaded_gantry_m,
                         cause=CostCause.DISPATCH, subject=crane_id)
        self.cost.accrue("empty_travel", plan.empty_gantry_m,
                         cause=CostCause.DISPATCH, subject=crane_id)
        self.cost.accrue("rehandle", float(plan.rehandles),
                         cause=CostCause.DISPATCH, subject=crane_id)
        self.queue.push(plan.start_s + plan.duration_s, EventKind.JOB_COMPLETED, crane_id)
        self.event_log.append((self.clock, "DISPATCH", f"{crane_id}:{plan.job_id}"))
        self._assigned[crane_id] = assignment

    def close_decision(self) -> None:
        if set(self._assigned) != set(self._pending):
            raise ConstraintViolation("DECISION_COVERAGE",
                                      f"{set(self._assigned)} != {set(self._pending)}")
        self._pending = ()
        self._refresh_rates()
        if self._check:
            self.check_invariants()

    def commit_decisions(self, assignments: list[CraneAssignment]) -> None:
        for a in sorted(assignments, key=lambda x: x.crane_id):
            self.assign(a.crane_id, a)
        self.close_decision()

    def dry_run_commit(self, choices: dict) -> CommitProjection:
        """resolver joint-feasibility 오라클 — choices{crane_id→JobRef|None} 를 실제 커밋과
        동일 경로(_plan + reject_reason, crane_id 순)로 시뮬한다. 라이브 상태 미변형.

        불변식(D-ORACLE): dry_run.plans == commit 실제 배정 plans → resolver 가 수용한 joint 는
        assign→reserve() 에서 예외 없이 통과한다.
        """
        scratch = copy.deepcopy(self.reservations)
        plans: dict = {}
        reasons: dict = {}
        for cid in sorted(choices):
            ref = choices[cid]
            if ref is None:
                continue
            plan = self._plan(cid, ref, extra_exclude=scratch.reserved_slots())
            if plan is None:
                reasons[cid] = "NO_PLAN"
                continue
            r = self._reservation(plan)
            reason = scratch.reject_reason(r)
            if reason is not None:
                reasons[cid] = reason
                continue
            scratch.reserve(r)
            plans[cid] = plan
        return CommitProjection(plans, reasons)

    def last_assignments(self) -> dict[str, CraneAssignment]:
        return dict(self._assigned)

    def active_plan(self, crane_id: str):
        """실행 중 JobPlan (idle 이면 None) — 관측 계층의 상대 의도 산출용 (YR-056).

        이미 commit 된 사실(예약·이동 중 계획)만 노출 — 미래 예측·진실값 아님.
        """
        return self._active_plans.get(crane_id)

    # ------------------------------------------------------------- internals
    def _process_next_event(self):
        ev = self.queue.pop()
        self._advance(ev.time)
        self._handle(ev)
        self._refresh_rates()
        if self._check:
            self.check_invariants()

    def _advance(self, t: float):
        if t < self.clock - _EPS:
            raise RuntimeError(f"시간 역행 {self.clock}->{t}")
        if t > self.clock:
            lo, hi = min(self.clock, self.end), min(t, self.end)
            if hi > lo:
                q0, tl0 = self.kpis.queue_area_s, self.kpis.tail_area_s
                self.kpis.integrate(lo, hi)          # S−B 대기 적분 (v2 에선 진단 지표로만)
                if self.time_ledger is not None:
                    # YR-089 v2: 학습비용 = 블록 처리시간(B→C) 점유 적분 — 대기+서비스.
                    # "빨리 시작했지만 오래 처리한" 정책의 오채택 방지 (spec 학습표적).
                    b0, bt0 = self.time_ledger.block_area_s, self.time_ledger.block_tail_area_s
                    self.time_ledger.integrate(lo, hi)
                    self.cost.accrue("truck_wait", self.time_ledger.block_area_s - b0,
                                     cause=CostCause.WAIT_INTEGRAL)
                    self.cost.accrue("long_wait", self.time_ledger.block_tail_area_s - bt0,
                                     cause=CostCause.WAIT_INTEGRAL)
                else:
                    self.cost.accrue("truck_wait", self.kpis.queue_area_s - q0,
                                     cause=CostCause.WAIT_INTEGRAL)
                    self.cost.accrue("long_wait", self.kpis.tail_area_s - tl0,
                                     cause=CostCause.WAIT_INTEGRAL)
                self.transfer.integrate(lo, hi)
                occ = frozenset(r.lane_id for r in self.reservations.active() if r.lane_id)
                self.lanes.integrate(lo, hi, occ)
                for v in self.vessels.values():
                    if v.sts_blocked and not v.done:
                        v.sts_wait_accum_s += (hi - lo)
                self.cost.advance(lo, hi)
            self.clock = t

    def _refresh_rates(self):
        self.cost.set_rate("sts_wait", sum(1 for v in self.vessels.values()
                                           if v.sts_blocked and not v.done))
        self.cost.set_rate("transfer_wait", self.transfer.waiting_count())
        occ = frozenset(r.lane_id for r in self.reservations.active() if r.lane_id)
        self.cost.set_rate("lane_cong", self.lanes.occupancy(occ)[0])
        self.cost.set_rate("interference", sum(1 for c in self.fleet.all() if c.yielded))
        self.cost.set_rate("imbalance", self.load_imbalance() / self.profile.shift_len_s)

    def load_imbalance(self) -> float:
        """§10.2 크레인별 **작업부하** 불균형 I(t) ∈ [0,1] (YR-043 재정의).

        Load_i(t) = 현재 작업 잔여시간 + 할당·예약 작업 예상 서비스시간 (idle=0).
        I(t) = (max−min)/Σ Load, Σ=0 이면 0.

        누적 완료건수 pstdev 는 폐기 — 처리건수 균등화는 사용자 목적이 아니었고, 누적·미정규화라
        총비용을 지배했다 (YR-039 무효 판정). rate=I/T_shift → ∫ 이 에피소드당 O(1).
        """
        loads = [max(0.0, c.state.available_at - self.clock) if c.state.assigned_job else 0.0
                 for c in self.fleet.all()]
        total = sum(loads)
        if total <= 0.0 or len(loads) < 2:
            return 0.0
        return (max(loads) - min(loads)) / total

    def _clear_yields(self):
        for c in self.fleet.all():
            c.yielded = False

    def _handle(self, ev):
        self.event_log.append((ev.time, ev.kind_name, ev.payload))
        k = ev.kind_name
        if k == "BLOCK_ARRIVAL":
            j = self.jobs[ev.payload]
            j.status = JobStatus.WAITING
            self.kpis.truck_arrived(j.job_id, ev.time)
            if self.time_ledger is not None:            # YR-089 v2: B 기록·블록 점유 시작
                self.time_ledger.block_arrival(j.job_id, ev.time)
            self._clear_yields()
        elif k == "JOB_RELEASED":
            self.jobs[ev.payload].status = JobStatus.RELEASED
            self._clear_yields()
        elif k == "JOB_COMPLETED":
            self._complete(ev.payload)
        elif k == "VESSEL_START":
            self._vessel_start(ev.payload)
        elif k == "STS_MOVE":
            self._sts_move(ev.payload)
        elif k == "TRANSFER_ARRIVE":
            self._transfer_arrive(ev.payload)
        elif k == "EQUIPMENT_DOWN":
            if ev.payload in self.fleet._cranes:
                self._equipment_down(ev.payload)
        elif k == "EQUIPMENT_UP":
            if ev.payload in self.fleet._cranes:
                yc = self.fleet.get(ev.payload)
                # down_pending 중(작업 진행 중) UP 이면 지연 DOWN 을 취소 — 정전이 실현 전 해소.
                yc.down = False
                yc.down_pending = False
                self._clear_yields()
        elif k == "PLAN_CHANGE":
            self._plan_change(ev.payload, ev.data)
        elif k == "VESSEL_RELEASED":
            # YR-080 단계2: 양하 박스 야드 인계 완료 → 해당 job 선택 가능.
            # 같은 시각 TRANSFER_ARRIVE(priority 2) 뒤에 처리(priority 3) — tie-break 고정.
            self.jobs[ev.payload].status = JobStatus.RELEASED
            self._clear_yields()
        elif k in ("HORIZON", "ETA_UPDATED"):
            pass
        else:
            raise RuntimeError(f"미지원 이벤트 {k}")

    def _complete(self, crane_id: str):
        plan = self._active_plans.pop(crane_id, None)
        yc = self.fleet.get(crane_id)
        if plan is None:
            raise RuntimeError(f"{crane_id} 완료 이벤트인데 활성 계획 없음")
        for mv in plan.moves:                      # 물리 실현 (dispatch 아님 — 여기서만)
            if mv.inbound is not None:
                self.stacks.place(mv.inbound, mv.dst[0], mv.dst[1])
            elif mv.depart:
                self.stacks.remove(mv.container_id)
            else:                                  # blocker 재배치 — 같은 객체를 재배치
                cont = self.stacks.containers[mv.container_id]
                self.stacks.remove(mv.container_id)
                self.stacks.place(cont, mv.dst[0], mv.dst[1])
        self.reservations.release(crane_id)
        yc.state.position_bay, yc.state.trolley_row = plan.end_bay, plan.end_row
        self.reservations.set_idle_position(crane_id, plan.end_bay)   # YR-091 상시 장벽 갱신
        yc.state.assigned_job = None
        yc.state.status = CraneStatus.IDLE
        yc.state.available_at = self.clock
        yc.is_loaded = False
        yc.recent_completions += 1
        yc.state.loaded_travel_m += plan.loaded_gantry_m
        yc.state.empty_travel_m += plan.empty_gantry_m
        self.kpis.add_travel(plan.loaded_gantry_m, plan.empty_gantry_m)
        self.kpis.add_rehandles(plan.rehandles)
        # SERVE 만 대상 job 을 완료·served 계상 (PRE_REHANDLE 은 target 잔존·job 미완료,
        # REPOSITION 은 job 없음 — kind 가드로 jobs.get(sentinel/PLANNED) 오설정 차단).
        if plan.kind == CandidateKind.SERVE:
            yc.served_count += 1
            j = self.jobs.get(plan.job_id)
            if j is not None:
                j.status = JobStatus.DONE
                j.service_end = self.clock
                j.rehandle_count = plan.rehandles
                self.kpis.job_completed(external=j.is_external_truck, deadline=j.deadline,
                                        end=self.clock)
                # YR-089 v2: C 기록·블록 점유 종료·O = C+exit_travel(외생) 확정
                if (self.time_ledger is not None and j.is_external_truck
                        and j.exit_travel_s is not None):
                    if getattr(j, 'visit_link', None) is None:
                        j.actual_gate_out = self.time_ledger.job_done(
                            j.job_id, self.clock, j.exit_travel_s)
                    else:
                        # [[YR-332-al]] one truck exit after its last job: record C now and
                        # the visit's exact O when it is known (or later, when it becomes known).
                        self.time_ledger.job_done_hold(j.job_id, self.clock)
                        if getattr(j, 'visit_gate_out', None) is not None:
                            j.actual_gate_out = self.time_ledger.set_gate_out(
                                j.job_id, j.visit_gate_out)
                # YR-080 단계3: 적하 반출 완료 → 박스를 안벽으로 이송 — 인과 사슬의
                # 적하 절반 (YC 반출 → YT → 안벽버퍼 → STS 처리 가능).
                if j.flow == JobFlow.VESSEL_LOAD and j.vessel_id is not None:
                    self._transfer_request(j.vessel_id)
                # YR-088: 양하 적재 완료 → 인계 파이프라인 1 해제 → 밀렸던 STS 재개(역압력 해소).
                elif (self.yard_handover_cap is not None
                      and j.flow == JobFlow.VESSEL_DISCHARGE and j.vessel_id is not None):
                    vid = j.vessel_id
                    outstanding = self._discharge_pipeline.get(vid, 0)
                    if outstanding <= 0:
                        raise ConstraintViolation("DISCHARGE_LEDGER", f"unreserved discharge {vid}")
                    self._discharge_pipeline[vid] = outstanding - 1
                    # YR-332-h: one block shares one fleet/capacity, including across
                    # overlapping calls. Freeing A's slot must also wake blocked B.
                    self._wake_discharge()
        if yc.down_pending:
            yc.down, yc.down_pending = True, False
        self._clear_yields()

    # ------------------------------------------------------------- vessel/transfer
    def _vessel_start(self, vid: str):
        v = self.vessels[vid]
        if v.started:
            return
        v.started = True
        v.remaining_moves = v.plan.total_moves
        # YR-080 단계3: 적하 유령 pre-fill 삭제 — 안벽 버퍼의 박스는 야드 반출 완료가
        # 만든다(_complete → _transfer_request). 야드작업과 무관하게 버퍼가 차던
        # 인과 단절(가중치를 올려도 행동 불변, YR-080d)의 적하 절반 교정.
        self.queue.push(self.clock + v.plan.sts_move_interval_s, EventKind.STS_MOVE, vid)

    def _can_sts_process(self, v) -> bool:
        if v.work_type == VesselWorkType.DISCHARGE:
            if (self.yard_handover_cap is not None
                    and sum(self._discharge_pipeline.values()) >= self.yard_handover_cap):
                return False                 # 인계버퍼 만재 — YC 적재가 밀림 (역압력)
            return v.buffer_level < v.plan.quay_buffer_cap
        return v.buffer_level > 0

    def _wake_discharge(self):
        """YR-332-h: reopen blocked streams after shared capacity is released.

        Events recheck capacity when executed; several wakes cannot overbook it.
        Clearing the blocked flag prevents duplicate wakes before the event runs.
        """
        for vid, v in sorted(self.vessels.items()):
            if (v.work_type == VesselWorkType.DISCHARGE and not v.done
                    and v.sts_blocked_since_s is not None and self._can_sts_process(v)):
                v.sts_blocked_since_s = None
                self.queue.push(self.clock, EventKind.STS_MOVE, vid)

    def _sts_move(self, vid: str):
        v = self.vessels[vid]
        if v.done or not v.started:
            return
        if not self._can_sts_process(v):
            if v.sts_blocked_since_s is None:
                v.sts_blocked_since_s = self.clock
            return
        if v.sts_blocked_since_s is not None:
            v.sts_blocked_since_s = None
        if v.work_type == VesselWorkType.DISCHARGE:
            v.buffer_level += 1
            if self.yard_handover_cap is not None:   # STS 뽑기 = 인계 파이프라인 진입
                self._discharge_pipeline[vid] = self._discharge_pipeline.get(vid, 0) + 1
            self._transfer_request(vid)      # 양하 박스 → 야드 이송 (도착 시 job 해제)
        else:
            v.buffer_level -= 1              # 적하 소비 — 보충은 야드 반출 완료가 (단계3)
        v.remaining_moves -= 1
        if v.remaining_moves <= 0:
            self._vessel_finish(vid)
        else:
            self.queue.push(self.clock + v.plan.sts_move_interval_s, EventKind.STS_MOVE, vid)

    def _transfer_request(self, vid: str):
        arrive = self.transfer.request(self.clock, vid)
        if arrive is not None:
            self.queue.push(arrive, EventKind.TRANSFER_ARRIVE, vid)

    def _release_next_discharge(self, vid: str):
        """양하 박스 1개 야드 인계 → 그 선박의 다음 PLANNED 양하 job 1건 해제 (FIFO).

        YR-080 단계2 — job_id 정렬 = 생성 순 FIFO (결정론). 이벤트로 우회해
        event_log 가시성·동시각 tie-break(TRANSFER_ARRIVE 2 → VESSEL_RELEASED 3) 고정.
        """
        for jid in sorted(self.jobs):
            j = self.jobs[jid]
            if (j.vessel_id == vid and j.status == JobStatus.PLANNED
                    and j.service_mode == ServiceMode.STORE):
                self.queue.push(self.clock, EventKind.VESSEL_RELEASED, jid)
                return

    def _transfer_arrive(self, vid: str):
        v = self.vessels[vid]
        if v.work_type == VesselWorkType.DISCHARGE:
            v.buffer_level = max(0, v.buffer_level - 1)   # box 야드 인계
            self._release_next_discharge(vid)             # YR-080: 도착 박스 = job 해제
        else:
            v.buffer_level += 1                           # box 안벽 staged
        nxt = self.transfer.dispatch_pending(self.clock)
        if nxt is not None:
            arrive, nvid = nxt
            self.queue.push(arrive, EventKind.TRANSFER_ARRIVE, nvid)
        if not v.done and v.sts_blocked_since_s is not None and self._can_sts_process(v):
            v.sts_blocked_since_s = None
            self.queue.push(self.clock, EventKind.STS_MOVE, vid)
        self._clear_yields()      # 버퍼 변화로 결정 지형이 바뀜 — yielded 크레인 재개방 (단계3)

    def _vessel_finish(self, vid: str):
        v = self.vessels[vid]
        v.done = True
        v.remaining_moves = 0
        v.sts_blocked_since_s = None
        v.truth.actual_completion_s = self.clock
        pc = v.plan.planned_completion_s
        if pc is not None and self.clock > pc:
            # YR-080 단계4: 비용(vessel_delay=선석 초과)과 보고 KPI(berth_overrun_s)를
            # **같은 호출부·같은 식**으로 동시 적립 — 학습이 최적화하는 양 == 보고하는 양.
            self.cost.accrue("vessel_delay", self.clock - pc,
                             cause=CostCause.VESSEL_FINISH, subject=vid)
            self.kpis.add_berth_overrun(self.clock - pc)
        if v.plan.etd_s is not None and self.clock > v.plan.etd_s:
            self.cost.accrue("depart_delay", self.clock - v.plan.etd_s,
                             cause=CostCause.VESSEL_FINISH, subject=vid)

    def _equipment_down(self, crane_id: str):
        yc = self.fleet.get(crane_id)
        if yc.state.assigned_job is not None:
            yc.down_pending = True         # 진행작업 무중단 (비선점) → 완료 후 DOWN
        else:
            yc.down = True

    def _plan_change(self, vid: str, data):
        v = self.vessels.get(vid)
        if v is None:
            return
        upd = dict(data or ())
        p = v.plan
        from .vessel import VesselPlan
        v.plan = VesselPlan(
            planned_start_s=p.planned_start_s,
            planned_completion_s=upd.get("planned_completion_s", p.planned_completion_s),
            completion_basis=upd.get("completion_basis", p.completion_basis),
            etd_s=upd.get("etd_s", p.etd_s), total_moves=p.total_moves,
            sts_move_interval_s=p.sts_move_interval_s, quay_buffer_cap=p.quay_buffer_cap,
            # YR-106-b: 물리 하한은 계획변경으로 바뀌지 않는다(설비·물량 불변) — 승계.
            phys_min_completion_s=p.phys_min_completion_s)
        for jid, dl in upd.get("job_deadlines", ()):
            if jid in self.jobs:
                self.jobs[jid].deadline = dl

    # ------------------------------------------------------------- finalize
    def _finalize(self):
        if self._terminal:
            return
        self._advance(max(self.clock, self.end))
        for v in self.vessels.values():
            # YR-080 단계4: is_symptom 제외 → **선석 종료시각 존재** 기준으로 교정 —
            # 결정3(적하도 계획시각 부여, 관측 SYMPTOM 은 별개)에 따라 미완 적하도
            # 선석 초과를 정산한다 (이전엔 SYMPTOM 이라 미완 clear-out 에서 누락).
            pc = v.plan.planned_completion_s
            if not v.done and pc is not None and self.end > pc:
                self.cost.accrue("vessel_delay", self.end - pc,
                                 cause=CostCause.CLEAROUT, subject=v.vessel_id)
                self.kpis.add_berth_overrun(self.end - pc)
        self.kpis.close_censored(self.end)
        if self.time_ledger is not None:      # YR-089 v2: 검열 기준시각 고정 (미완료 = end−A 노출)
            self.time_ledger.close(self.end)
        self._terminal = True

    # ------------------------------------------------------------- invariants
    def check_invariants(self):
        geom = self.profile.block
        seen: set[str] = set()
        for (bay, row), pile in self.stacks._stacks.items():
            if len(pile) > geom.tier_max:
                raise ConstraintViolation("TIER_OVERFLOW", f"({bay},{row})")
            for tier, cid in enumerate(pile, start=1):
                if cid in seen:
                    raise ConstraintViolation("DUP_CONTAINER", cid)
                seen.add(cid)
                c = self.stacks.containers[cid]
                if (c.bay, c.row, c.tier) != (bay, row, tier):
                    raise ConstraintViolation("POSITION_DESYNC", cid)
        if set(self.stacks.containers) != seen:
            raise ConstraintViolation("CONTAINER_LOST", "stack 불일치")
        busy = {c.crane_id for c in self.fleet.all() if c.state.assigned_job is not None}
        if set(self._active_plans) != busy:
            raise ConstraintViolation("PLAN_DESYNC", f"{set(self._active_plans)} != {busy}")
        if self.reservations.orphan_count() != len(self._active_plans):
            raise ConstraintViolation("RESERVE_DESYNC", "예약·계획 불일치")
        for c in self.fleet.all():
            spec = self.fleet.spec(c.crane_id)
            if not (spec.service_bay_min <= c.state.position_bay <= spec.service_bay_max):
                raise ConstraintViolation("OUT_OF_RANGE", f"{c.crane_id}")
        # YR-091: 비통과 순서·최소간격 — 레일 순서(초기 bay 오름차순)가 뒤집히면 관통이 있었던 것.
        # 이동 중 크레인의 position_bay 는 출발값(완료 시 갱신)이라 이벤트 경계에서 항상 유효.
        order = getattr(self, "_rail_order", ())
        gap = self.reservations.safety_gap_bay
        for a, b in zip(order, order[1:]):
            pa = self.fleet.get(a).state.position_bay
            pb = self.fleet.get(b).state.position_bay
            if pa > pb + _EPS:
                raise ConstraintViolation("CRANE_ORDER_SWAP", f"{a}({pa:.2f}) > {b}({pb:.2f})")
            if pb - pa < gap - _EPS:
                raise ConstraintViolation("CRANE_MIN_GAP", f"{a}·{b} 간격 {pb - pa:.2f} < {gap}")
        self._assert_pairwise_resources()

    def _assert_pairwise_resources(self):
        """상시 4-lock 무결성 — 삽입시점뿐 아니라 매 이벤트 후 active 예약 쌍별 검사 (YR-037)."""
        active = self.reservations.active()
        gap = self.reservations.safety_gap_bay
        for i in range(len(active)):
            for jx in range(i + 1, len(active)):
                a, b = active[i], active[jx]
                if a.job_token is not None and a.job_token == b.job_token:
                    raise ConstraintViolation("TOKEN_DOUBLE", f"{a.crane_id}·{b.crane_id} {a.job_token}")
                if a.lane_id is not None and a.lane_id == b.lane_id:
                    raise ConstraintViolation("LANE_DOUBLE", f"{a.crane_id}·{b.crane_id} {a.lane_id}")
                if a.corridor.overlaps(b.corridor, gap):
                    raise ConstraintViolation("CORRIDOR_OVERLAP", f"{a.crane_id}·{b.crane_id}")
                if a.slots & b.slots:
                    raise ConstraintViolation("SLOT_DOUBLE", f"{a.crane_id}·{b.crane_id}")

    def unfinished_backlog(self) -> int:
        # 외부감사 2차(2026-07-26): ASSIGNED·RUNNING 포함 — 평가창 정정 후 종료시점 작업 중
        # 인 job 도 미완료다. 이전엔 계획·대기·해제만 세어 "종료시점 작업 중 = backlog" 가
        # 이 경로에서 성립하지 않았다. (DONE·CANCELLED 만 backlog 아님.)
        return sum(1 for j in self.jobs.values()
                   if j.status not in (JobStatus.DONE, JobStatus.CANCELLED))

    def event_stream_hash(self) -> str:
        blob = "|".join(f"{round(t, 6)}:{k}:{p}" for (t, k, p) in self.event_log)
        return hashlib.sha1(blob.encode("utf-8")).hexdigest()[:16]


def _pstdev(xs: list[int]) -> float:
    if len(xs) <= 1:
        return 0.0
    m = sum(xs) / len(xs)
    return (sum((x - m) ** 2 for x in xs) / len(xs)) ** 0.5
