"""v3 판정 진입점 — 학생만 돈다.

■ 하드가드 (위반 시 그 셀 실격)
  1. 투입 = 전건 (`admitted == DIURNAL_DAY_TOTAL` — 2026-08-20 기준 7,500)
  2. `policy_exceptions == 0`
  3. 실행 트리 `code_dirty == False`  ← WSL 에서 GIT_DIR 없으면 None 이 되어
                                        가드가 조용히 무력화된다. 실행 전 확인.
  4. 전 셀 존재 (팔 수 × 날 수)
  5. **`rollout_calls_during_eval == 0`** — v3 신규. 교사가 판정에 새면 안 된다.

■ 사전등록
  주판정 축(규칙 대비) · 모드 · 평가 대역을 **실행 전에 동결**한다.
  사용한 대역 재사용 금지: 9,200,000 · 9,300,000~ · 9,600,000~ ·
  9,700,000~ · 9,800,000~ · 비판정 9,900,0xx

■ 설계 문서: `.claude/docs/architecture/06-학습과-판정.md` §2·§3
"""

from .guards import (DIAGNOSTIC_BAND, USED_BANDS, GuardReport, check_bands,
                     check_cell, check_matrix)
from .month_judge import JUDGE_ARMS, judge_month, sign_test
from .run import (DISPATCHERS, EVAL_LOADS, GENERALITY_ARMS, LOAD_LEVELS,
                  MAIN_DISPATCHER, REALLOC_ARMS, TRAIN_LOADS, WINDOW_SWEEP_S,
                  CellResult, default_episode_fn, paired_gap, plan_cells,
                  run_cell)

__all__ = ["check_cell", "check_bands", "check_matrix", "GuardReport",
           "USED_BANDS", "DIAGNOSTIC_BAND", "plan_cells", "run_cell",
           "paired_gap", "CellResult", "LOAD_LEVELS", "DISPATCHERS",
           "REALLOC_ARMS", "MAIN_DISPATCHER", "GENERALITY_ARMS",
           "default_episode_fn", "TRAIN_LOADS", "EVAL_LOADS", "WINDOW_SWEEP_S"]
