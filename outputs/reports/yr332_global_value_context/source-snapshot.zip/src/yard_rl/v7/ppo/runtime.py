"""Fixed-policy collection, shared team rewards, and in-place on-policy updates."""
from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
import math

import numpy as np
import torch

from ..features.block import block_features
from ..reward.phi import terminal_cost_krw
from ..schema.lifecycle import TRUCK_TIME_CONTRACT
from ..reward.scaling import default_reward_scale, scaling_report
from ..reward.operational import KEYS, reference_config, runtime_totals, normalized_loss
from ..stage.episode import rehandles_of, yc_empty_travel_s
from ..stage.month import month_vessel_idle
from .buffer import Choice, Interval
from .crane import CraneActor
from .model import BlockPolicy, encode
from .update import update


class DebugStop(Exception):
    """Requested short-run limit at a synchronized boundary, not an engine failure."""


@dataclass(frozen=True)
class PPOConfig:
    rollout_intervals: int = 60
    epochs: int = 2
    minibatch_size: int = 64
    learning_rate: float = 3e-4
    gamma: float = 0.999
    gae_lambda: float = 0.95
    time_unit_s: float = 60.0
    reward_scale_krw: float | None = None  # None derives the scale from the frozen reference.
    reward_mode: str = 'operational'
    clip: float = 0.2
    value_coef: float = 0.5
    entropy_coef: float = 0.001
    max_grad_norm: float = 0.5
    target_kl: float = 0.03

    def __post_init__(self):
        counts = (self.rollout_intervals, self.epochs, self.minibatch_size)
        if any(not isinstance(v, int) or isinstance(v, bool) for v in counts):
            raise ValueError("Batch sizes and epochs must be positive integers")
        if any(not math.isfinite(float(v)) for k, v in asdict(self).items()
               if k != 'reward_mode' and not (k == 'reward_scale_krw' and v is None)):
            raise ValueError("PPO configuration must be finite")
        if self.reward_mode not in ('operational', 'legacy-krw'):
            raise ValueError('Unknown reward mode')
        if self.reward_mode == 'operational' and self.reward_scale_krw is not None:
            raise ValueError('Operational rewards do not use a KRW scale')
        if self.reward_mode == 'legacy-krw' and self.reward_scale_krw is None:
            object.__setattr__(self, 'reward_scale_krw', default_reward_scale(
                gamma=self.gamma, time_unit_s=self.time_unit_s))
        if min(self.rollout_intervals, self.epochs, self.minibatch_size) < 1:
            raise ValueError("Batch sizes and epochs must be positive")
        if self.reward_scale_krw is not None and self.reward_scale_krw <= 0:
            raise ValueError('PPO scales must be positive')
        if min(self.learning_rate, self.time_unit_s,
               self.max_grad_norm, self.target_kl) <= 0:
            raise ValueError("PPO scales must be positive")
        if not (0 < self.gamma <= 1 and 0 <= self.gae_lambda <= 1 and 0 < self.clip < 1):
            raise ValueError("Invalid discount / clip")
        if min(self.value_coef, self.entropy_coef) < 0:
            raise ValueError("Loss coefficients cannot be negative")


class PPORuntime:
    def __init__(self, policy: BlockPolicy, *, config=None, seed=302,
                 training=True, stop_s=None, on_update=None, learning_window_s=None,
                 on_boundary=None, sample_actions=None, workload=None):
        if stop_s is not None and (not math.isfinite(stop_s) or stop_s <= 0):
            raise ValueError("stop_s must be finite and positive")
        self.policy, self.config = policy, config or PPOConfig()
        self.reward_contract = reward_contract(self.config)
        check_reward_contract(policy, self.config, self.reward_contract)
        self.training, self.stop_s, self.on_update = bool(training), stop_s, on_update
        #: ★행동을 **추첨으로 뽑을지**(True) **최고점만 고를지**(False) — [[YR-319]].
        #:
        #: 예전에는 `training` 하나가 둘을 겸했다: 학습 중이면 추첨, 고정 운영이면 최고점.
        #: 그래서 [[YR-306]] 비교가 **가중치 고정**과 **최고점 선택**을 **한꺼번에** 바꿨고,
        #: 172배 격차가 어느 쪽 탓인지 귀속이 안 됐다. 이 칸이 둘을 가른다.
        #: 기본값은 `training` 을 그대로 따라가므로 **기존 실행의 동작은 바뀌지 않는다.**
        self.sample_actions = (bool(training) if sample_actions is None
                               else bool(sample_actions))
        if learning_window_s is not None:
            start, end = learning_window_s
            if not (math.isfinite(start) and math.isfinite(end) and 0 <= start < end):
                raise ValueError("Learning window must be finite, nonnegative and increasing")
            learning_window_s = (float(start), float(end))
        self.learning_window_s, self.on_boundary = learning_window_s, on_boundary
        self.optimizer = torch.optim.Adam(policy.parameters(), lr=self.config.learning_rate)
        self.rng = np.random.default_rng(seed)
        self.action_rng = torch.Generator(device="cpu").manual_seed(seed)
        self.buffer, self.updates = [], []
        self.role_counts, self.crane_actions = Counter(), Counter()
        self.time_s, self.initial_cost, self.cost_krw = None, None, 0.0
        self.total_reward, self.intervals = 0.0, 0
        self.physical = self.initial_physical = None
        self.objective = self.initial_objective = 0.
        self.learning_reward, self.learning_intervals = 0.0, 0
        self.workload = workload
        self.potential = None
        self.shaping_reward = self.learning_shaping_reward = 0.0
        self.last_shaping_reward = 0.0
        self.execute = CraneActor(self)
        self.truncated = False
        self.bound = False

    def collecting_at(self, t):
        return self.training and (self.learning_window_s is None or
                                  self.learning_window_s[0] <= t < self.learning_window_s[1])

    def bind(self, mbt, bridge, meta, archive):
        if self.bound:
            raise RuntimeError("A runtime belongs to exactly one continuous world")
        if bridge.on_decision is not None:
            raise ValueError("Counterfactual teacher must be disabled")
        self.mbt, self.bridge, self.meta, self.archive = mbt, bridge, meta, archive
        self.bids = sorted(mbt.blocks)
        self.index = {b: i for i, b in enumerate(self.bids)}
        self.block_of = {id(mbt.blocks[b]): b for b in self.bids}
        self.bound = True
        if self.workload is not None:
            self.workload.bind(mbt, bridge)

    def block_state(self, bid, t):
        return block_features(self.mbt, bid, t, n_cands=None,
                              records=self.bridge.records, orders=self.bridge.orders,
                              end_s=self.bridge.end_s)

    def states_at(self, t):
        return encode([self.block_state(b, t) for b in self.bids], "state")

    def read_cost(self, t):
        phi = terminal_cost_krw(self.bridge.records, end_s=t,
                               vessel_idle=month_vessel_idle(self.mbt, self.meta, self.archive),
                               yc_extra_move_s=yc_empty_travel_s(self.mbt),
                               rehandles=rehandles_of(self.mbt))
        self.cost_breakdown = phi.as_dict()
        return float(phi.total)

    def read_operational(self, t):
        return runtime_totals(self, t)

    def select(self, role, bid, t, rows, mask=None):
        if not math.isfinite(t) or t < 0:
            raise ValueError("Decision time must be finite and nonnegative")
        if self.time_s is None:
            raise RuntimeError("A synchronized initial boundary must precede decisions")
        if t < self.time_s - 1e-6:
            raise RuntimeError("Decision timestamp precedes the collection interval")
        x = encode(rows, role)
        mask = torch.ones(len(x), dtype=torch.bool) if mask is None else mask.clone().bool()
        with torch.no_grad():
            dist = self.policy.distribution(x, mask)
            action = (int(torch.multinomial(dist.probs, 1, generator=self.action_rng))
                      if self.sample_actions else int(dist.probs.argmax()))
            logp = float(dist.log_prob(torch.tensor(action)))
        if self.collecting_at(self.time_s):
            self.pending[self.index[bid]].append(Choice(role, t, x, mask, action, logp))
        self.role_counts[role] += 1
        return action

    def _update(self, bootstrap):
        if not self.training or not self.buffer:
            return
        rep = update(self.policy, self.optimizer, self.buffer, bootstrap, self.config, self.rng)
        rep.update(index=len(self.updates) + 1, time_s=self.time_s, cost_krw=self.cost_krw)
        self.updates.append(rep)
        self.buffer.clear()
        if self.on_update is not None:
            self.on_update(rep)

    def boundary(self, t, *, terminated=False, final=False):
        if not math.isfinite(t) or t < 0:
            raise ValueError("Review time must be finite and nonnegative")
        if self.time_s is not None and t < self.time_s - 1e-6:
            raise RuntimeError("Review clock went backwards")
        states = self.states_at(t)
        with torch.no_grad():
            bootstrap = self.policy.value(states).numpy().copy()
        cost = self.read_cost(t)
        physical = self.read_operational(t) if self.config.reward_mode == 'operational' else None
        objective = (normalized_loss(physical, self.reward_contract) if physical is not None
                     else cost / self.config.reward_scale_krw)
        next_potential = (0.0 if terminated else self.workload.snapshot(t)) if self.workload else 0.0
        if not math.isfinite(cost):
            raise FloatingPointError("Non-finite environment cost")
        if self.initial_cost is None:
            self.initial_cost = cost
            self.initial_objective, self.initial_physical = objective, physical
        elif t > self.time_s + 1e-6:
            if self.learning_window_s is not None and any(
                    self.time_s < edge < t for edge in self.learning_window_s):
                raise RuntimeError("A review must occur exactly at each learning-window boundary")
            delta = cost - self.cost_krw
            if delta < -1e-5:
                raise RuntimeError("Cumulative cost fell: lost/pruned accounting data")
            if physical is None:
                reward = -delta / self.config.reward_scale_krw
            else:
                changes = {k: physical[k]-self.physical[k] for k in KEYS}
                if min(changes.values()) < -1e-5:
                    raise RuntimeError('Cumulative physical ledger decreased')
                reward = -normalized_loss(changes, self.reward_contract)
            shaping = (self.workload.config.eta * (
                self.config.gamma ** ((t - self.time_s) / self.config.time_unit_s)
                * next_potential - self.potential)) if self.workload else 0.0
            self.last_shaping_reward = shaping
            self.shaping_reward += shaping
            self.total_reward += reward
            self.intervals += 1
            if self.collecting_at(self.time_s):
                self.learning_reward += reward
                self.learning_shaping_reward += shaping
                self.learning_intervals += 1
                self.buffer.append(Interval(self.time_s, t, self.states, self.values,
                                             self.pending, reward + shaping, terminated))
        elif not final:
            return  # Repeated reviews must not erase decisions or charge cost twice.
        self.time_s, self.cost_krw = float(t), cost
        self.objective, self.physical = objective, physical
        self.potential = next_potential
        should_stop = self.stop_s is not None and t >= self.stop_s - 1e-6
        if (len(self.buffer) >= self.config.rollout_intervals or final or should_stop
                or not self.collecting_at(t)):
            self._update(np.zeros_like(bootstrap) if terminated else bootstrap)
        # Values MUST be recollected after an update, for the next on-policy batch.
        self.states = states
        with torch.no_grad():
            self.values = self.policy.value(states).numpy().copy()
        self.pending = [[] for _ in self.bids]
        if self.on_boundary is not None:
            self.on_boundary(self)
        if should_stop and not final:
            self.truncated = True
            raise DebugStop(f"Debug time limit {t:g}s; unfinished work retained")

    def finish(self, t, *, terminated=False):
        self.boundary(t, terminated=terminated, final=True)
        self.truncated = not terminated

    def report(self):
        return {"generation": "v6", "algorithm": "shared-block-PPO",
                "time_s": self.time_s, "blocks": len(self.bids),
                "intervals": self.intervals, "roles": dict(self.role_counts),
                "crane_actions": dict(self.crane_actions), "cost_krw": self.cost_krw,
                "initial_cost_krw": self.initial_cost, "team_reward": self.total_reward,
                "learning_window_s": self.learning_window_s,
                "learning_intervals": self.learning_intervals,
                "learning_reward": self.learning_reward,
                "shaping_reward": self.shaping_reward,
                "learning_shaping_reward": self.learning_shaping_reward,
                "learning_training_reward": self.learning_reward + self.learning_shaping_reward,
                "workload": self.workload.report() if self.workload else None,
                "truncated": self.truncated, "updates": self.updates,
                "traded_edges": self.bridge.traded_edges, "txn_failed": self.bridge.txn_failed,
                "n_space": self.bridge.n_space, "n_time": self.bridge.n_time,
                "cost_breakdown": self.cost_breakdown,
                "config": asdict(self.config),
                "reward_mode": self.config.reward_mode, "physical_totals": self.physical,
                "initial_physical_totals": self.initial_physical,
                "objective": self.objective, "initial_objective": self.initial_objective,
                "reward_normalization": self.reward_contract}


def reward_contract(config):
    if config.reward_mode == 'operational':
        return reference_config(gamma=config.gamma, time_unit_s=config.time_unit_s)
    return scaling_report(config.reward_scale_krw, gamma=config.gamma, time_unit_s=config.time_unit_s) | {
        'truck_time_contract': TRUCK_TIME_CONTRACT}


def check_reward_contract(policy, config, contract=None):
    mode = getattr(policy, 'checkpoint_reward_mode', None)
    if mode is not None and mode != config.reward_mode:
        raise ValueError('Checkpoint reward mode differs; train fresh or replay its recorded mode')
    if mode is not None and (getattr(policy, 'checkpoint_reward_contract', None) or {}).get(
            'truck_time_contract') != TRUCK_TIME_CONTRACT:
        raise ValueError('Checkpoint truck time contract differs; old exit-based rewards cannot resume')
    if mode == 'operational':
        if policy.checkpoint_reward_contract != (contract or reward_contract(config)):
            raise ValueError('Checkpoint operational reference/weights differ')
    else:
        scale = getattr(policy, 'checkpoint_reward_scale_krw', None)
        if scale is not None and scale != config.reward_scale_krw:
            raise ValueError('Checkpoint reward scale differs: use its explicit config for replay')
