"""Explicit, optional demand calibration for the CPU daily diagnostic.

Flow probability, clock-hour masses and the within-hour arrival process are
independent input axes. Total demand, block assignment, inventory, vessel plans,
service physics and reward stay owned by the existing stage. Without a
`within_hour` field the old stratified (evenly spaced) arrivals are unchanged.
"""
from __future__ import annotations

import bisect
import math
import random

SCHEMA = 'observed-truck-demand-marginals-v1'
WITHIN_HOUR_METHODS = ('poisson', 'observed_visit_minutes', 'dirichlet_minutes', 'correlated_minutes')
DATE_ORDERS = ('random', 'busiest_first')


def validate(profile: dict, *, day_s: float) -> None:
    if profile.get('schema') != SCHEMA:
        raise ValueError('unknown demand profile schema')
    if day_s != 86400.0:
        raise ValueError('observed demand profile requires the 24-hour daily stage')
    if not set(profile).issubset({'schema','gate_out_share','hour_counts','within_hour','visit_link','source'}):
        raise ValueError('unsupported demand profile field')
    if profile.get('within_hour') is not None:
        validate_within_hour(profile['within_hour'])
    if profile.get('visit_link') is not None:
        # Visits take the within-hour template; orders inherit their visit time ([[YR-332-al]]).
        from .visit_link import validate_visit_link
        validate_visit_link(profile['visit_link'])
        if profile.get('within_hour') is None or profile.get('hour_counts') is None:
            raise ValueError('visit_link requires hour_counts and a within_hour template')
    p=profile.get('gate_out_share')
    if p is not None and (not math.isfinite(p) or not 0 <= p <= 1):
        raise ValueError('gate_out_share must be a finite probability')
    counts=profile.get('hour_counts')
    if counts is not None:
        if len(counts)!=24 or any(not math.isfinite(x) or x<0 for x in counts) or sum(counts)<=0:
            raise ValueError('hour_counts requires 24 finite nonnegative masses and a positive total')


def hourly_arrivals(seed: int, total: int, counts: list[float]) -> list[float]:
    """Same stratified quantiles as the old curve; only the arrival CDF changes."""
    validate(dict(schema=SCHEMA,hour_counts=counts),day_s=86400.)
    if total < 0:
        raise ValueError('negative order count')
    cumulative=[0.]
    for x in counts:
        cumulative.append(cumulative[-1]+x)
    rng=random.Random(f'h21d:arr:{seed}')
    times=[]
    for i in range(total):
        q=cumulative[-1]*(i+rng.random())/total
        hour=min(23,bisect.bisect_right(cumulative,q)-1)
        fraction=(q-cumulative[hour])/(cumulative[hour+1]-cumulative[hour])
        # The schedule stores milliseconds; never round up into the next day.
        times.append(min(86399.999,round((hour+fraction)*3600.,3)))
    return times


def validate_within_hour(spec: dict) -> None:
    """`poisson`: independent uniform times inside each hour (random, no clustering).
    `observed_visit_minutes`: per-minute counts of observed truck visits for each
    date and clock hour (aggregate counts, no identifiers)."""
    if not isinstance(spec, dict) or spec.get('method') not in WITHIN_HOUR_METHODS:
        raise ValueError('unknown within-hour arrival method')
    if spec['method'] == 'poisson':
        if not set(spec).issubset({'method', 'source'}):
            raise ValueError('unsupported within-hour field')
        return
    if spec['method'] == 'dirichlet_minutes':
        if not set(spec).issubset({'method', 'alpha', 'source'}):
            raise ValueError('unsupported parametric within-hour field')
        alpha = spec.get('alpha')
        if not isinstance(alpha, (float, int)) or not math.isfinite(alpha) or alpha <= 0:
            raise ValueError('positive finite minute concentration required')
        return
    if spec['method'] == 'correlated_minutes':
        from .correlated_arrivals import validate as validate_parameters
        if not set(spec).issubset({'method', 'parameters', 'source'}):
            raise ValueError('unsupported correlated within-hour field')
        validate_parameters(spec.get('parameters'))
        return
    if not set(spec).issubset({'method', 'dates', 'minute_counts', 'date_order', 'source'}):
        raise ValueError('unsupported within-hour field')
    if spec.get('date_order', 'random') not in DATE_ORDERS:
        raise ValueError('unknown observed date order')
    dates = spec.get('dates')
    if not dates or len(set(dates)) != len(dates):
        raise ValueError('observed templates need distinct dates')
    counts = spec.get('minute_counts')
    if not isinstance(counts, dict) or set(counts) != {str(h) for h in range(24)}:
        raise ValueError('observed templates need all 24 clock hours')
    for hour, days in counts.items():
        if len(days) != len(dates):
            raise ValueError('one minute vector per date is required')
        for minutes in days:
            if len(minutes) != 60 or any(not isinstance(x, int) or x < 0 for x in minutes):
                raise ValueError('minute vectors need 60 nonnegative integers')
        if sum(map(sum, days)) <= 0:
            raise ValueError(f'hour {hour} has no observed arrivals')


def within_hour_arrivals(seed: int, times: list[float], spec: dict) -> tuple[list[float], dict]:
    """Redraw times inside each clock hour only.

    Each hour keeps its count and the entries keep their order, so flows, blocks and
    targets stay attached to the same arrival rank. `observed_visit_minutes` stacks
    whole observed dates of the same clock hour until the hour is filled; only the
    last date is subsampled. A higher load therefore superposes more observed days.
    `date_order='random'` stacks dates in a seeded random order (first YR-332-ak
    draft, failed its preregistered input check). `'busiest_first'` stacks the
    dates with the most visits in that clock hour first (ties in seeded random
    order), so the fewest and most volume-similar observed days are superposed.
    Times are uniform inside the drawn minute.
    """
    validate_within_hour(spec)
    hours: dict[int, list[int]] = {}
    for i, t in enumerate(times):
        if not 0 <= t < 86400:
            raise ValueError('arrival outside the 24-hour stage')
        hours.setdefault(int(t // 3600), []).append(i)
    out = list(times)
    date_order = spec.get('date_order', 'random')
    meta = dict(method=spec['method'], hours={})
    if spec['method'] == 'observed_visit_minutes':
        meta['date_order'] = date_order
    for hour, index in sorted(hours.items()):
        index.sort(key=lambda i: (times[i], i))
        n = len(index)
        key = spec['method'] if date_order == 'random' or spec['method'] == 'poisson' else f"{spec['method']}:{date_order}"
        rng = random.Random(f"h21d:within:{key}:{seed}:{hour}")
        if spec['method'] == 'poisson':
            offsets = [3600. * rng.random() for _ in range(n)]
            meta['hours'][str(hour)] = dict(n=n)
        elif spec['method'] in ('dirichlet_minutes', 'correlated_minutes'):
            if spec['method'] == 'correlated_minutes':
                from .correlated_arrivals import weights as minute_weights
                weights = minute_weights(rng, spec['parameters'])
            else:
                weights = [rng.gammavariate(spec['alpha'], 1.) for _ in range(60)]
            cumulative = []
            for w in weights:
                cumulative.append(w + (cumulative[-1] if cumulative else 0.))
            if not math.isfinite(cumulative[-1]) or cumulative[-1] <= 0:
                raise ValueError('degenerate Dirichlet minute draw')
            minutes = [min(59, bisect.bisect_right(cumulative, rng.random() * cumulative[-1]))
                       for _ in range(n)]
            offsets = [60. * (m + rng.random()) for m in minutes]
            meta['hours'][str(hour)] = dict(n=n, **({'alpha': spec['alpha']} if spec['method'] == 'dirichlet_minutes'
                                                  else {'parameters': dict(spec['parameters'])}))
        else:
            days = spec['minute_counts'][str(hour)]
            order = list(range(len(days)))
            rng.shuffle(order)
            if date_order == 'busiest_first':
                order.sort(key=lambda d: -sum(days[d]))
            minutes: list[int] = []
            used = 0
            whole = 0
            while len(minutes) < n:
                day = days[order[used % len(order)]]
                used += 1
                pool = [m for m, c in enumerate(day) for _ in range(c)]
                need = n - len(minutes)
                if len(pool) <= need:
                    minutes += pool
                    whole += len(pool) > 0
                else:
                    minutes += rng.sample(pool, need)
            offsets = [60. * m + 60. * rng.random() for m in minutes]
            meta['hours'][str(hour)] = dict(n=n, dates_used=used, whole_dates=whole,
                                            cycled=used > len(order))
        offsets = sorted(min(3599.999, round(x, 3)) for x in offsets)
        for i, x in zip(index, offsets):
            out[i] = min(86399.999, round(hour * 3600. + x, 3))
    meta['cycled_hours'] = sum(bool(h.get('cycled')) for h in meta['hours'].values())
    return out, meta
