"""크레인 정책 — 비용을 읽고 다음 일감을 고른다 ([[YR-248]] 2단계 · v7 이식 [[YR-332-b]]).

v4 `crane/policy.py` 를 옮겼다. 바뀐 것은 입력 차원(8 → 9, `features.py`)뿐이다.

■ 지금까지 크레인은 규칙이었다
  `SF_SPT` 는 정렬키가 다섯 자리지만 실제 승부는 **소요시간 61.6% · 이름순 33.6%**
  로 갈린다([[YR-242]] 실측). 즉 **사실상 최단작업 우선이고 이름순이 3분의 1을 정한다.**
  비용을 한 줄도 안 읽는다.

■ 무엇이 바뀌나 — `rank()` 하나만
  `Preference.rank(sim, crane_id, gc) -> tuple` 이 규약이고, 작을수록 먼저다.
  규칙 바닥은 `(실작업 우선, 정렬키, job_id)` 를 돌려주는데, 여기서는
  **망이 매긴 상대비용**을 그 자리에 넣는다. 나머지 구조는 그대로다.

■ v3 재배정층과 같은 방식으로 배운다
  자기 추정으로 자기를 가르치지 않는다(부트스트랩 없음). 시뮬레이터가 **실제로 굴려 잰**
  비용 차이를 정답으로 쓴다. 그래서 이 망은 *"이 후보를 고르면 그 뒤 비용이 평균보다
  얼마나 낮은가"* 를 낸다 — 절대 비용이 아니라 **짝 중심 상대값**이다.

■ ⚠️ 학습 전에는 규칙보다 나쁘다
  초기 망은 무작위라 `rank` 가 잡음이다. 그래서 `RuleBase` 처럼 **실작업 우선**을
  맨 앞 자리에 그대로 둔다 — 학습이 덜 돼도 *"일은 안 하고 자리이동만 고르는"*
  퇴화([[YR-039]] · 결정의 54~81%가 REPOSITION 이었다)로 무너지지 않는다.
  망은 **그 안에서 순서만** 정한다. 이 울타리를 걷는 것은 효과가 실증된 뒤에 한다.
"""
from __future__ import annotations

import struct
import torch
from torch import nn

from ..world.contract.schema import CandidateKind
from ..world.integrated.resolver import BaselinePreference
from .features import CRANE_DIM, COUNT_TRANSFORMS, crane_features, decision_common

#: 학습 목표 눈금 — 원화를 망이 다루기 좋은 크기로 바꾼다.
#: ⚠️ 재배정층 `ADV_SCALE` 과 **같은 이유·같은 규약**이다: 조건이 바뀌면 재실측 후 동결.
#:
#: ★실측으로 동결했다 ([[YR-308]] · 2026-09-10 · 179건 · 창 3시간):
#:
#:      부하    라벨   격차 중앙    격차 평균      격차 최대    차이0 비율
#:     3,500     64      6,721원     27,606원     162,286원      18.8%
#:     7,500     59      8,589원     71,730원     649,111원      20.3%
#:    15,000     56     15,472원    121,393원   1,085,555원      14.3%
#:                    ─────────
#:                전체 중앙 9,470원  →  **10,000원** 으로 못박는다
#:
#:   부하별 목표 중앙이 0.67 · 0.86 · 1.55 로 전부 적정대(0.3~3.0) 안이다.
#:
#: ■ 왜 중앙값인가 — 분포가 **한쪽으로 길다**
#:   평균이 중앙의 4~8배다(6,721 vs 27,606). 대부분의 크레인 선택은 3시간 뒤 비용을
#:   거의 안 바꾸고(차이가 정확히 0 인 결정이 **약 18%**), 드물게 백만원짜리가 있다.
#:   평균에 맞추면 그 꼬리가 눈금을 끌어올려 **평범한 결정이 전부 0 근처로 뭉갠다.**
#:   꼬리는 Huber(β=1)가 선형 구간에서 받아 준다 — 눈금이 아니라 손실함수의 몫이다.
#:
#: ■ ⚠️ 잠정값 100,000 이었을 때 무슨 일이 났나
#:   재배정층에서 빌려온 값이라 목표 중앙이 **0.095** 였다 — 신호가 0 근처로 뭉개져
#:   학습이 사실상 안 됐을 것이다. [[YR-299]] B 가 이 계측이 없어 눈금 문제를
#:   검증조차 못 했던 그 실패를 여기서는 계측이 막았다.
#:
#: ■ ★이제는 **기본값·보고용 참조값**이다 ([[YR-309]] · 2026-09-11)
#:   실제 학습은 **그날 라벨의 중앙 격차**로 나눈다 — 아래 `CRANE_SCALE_FLOOR` 참조.
#:   이 상수는 헬퍼의 기본 인자와 *"대략 이 자릿수"* 를 가리키는 용도로 남는다.
#:
#: ■ ★v7 에서는 **다시 재야 한다** ([[YR-332-b]] · 값은 v4 그대로 두고 동결하지 않는다)
#:   위 실측은 v4 무대에서 잰 값이다(그때 본선 단가가 2.99 였는지 35.88 이었는지는
#:   기록에서 확인하지 못했다 — 둘 다 2026-09-10). v7 은 무대가 다르다 — 본선 35.88원·
#:   DGT 리드타임·미리 자리잡는 빈 이동 끔·v6 사본 물리. 그래서 학습 경로는 원래대로 **그날 라벨의 중앙 격차**를 눈금으로 쓰고(YR-309),
#:   이 상수는 출발점·보고용 참조로만 남는다. 다시 재는 계측:
#:   `scripts/v7/probe_crane_scale.py` (부하별 격차 중앙·하한 걸림·차이0 비율).
CRANE_ADV_SCALE = 10_000.0

#: ★날별 눈금의 **하한** ([[YR-309]]).
#:
#: 왜 날마다 다시 재나 — [[YR-308]] 4시간 학습이 요동친 원인 가설이다.
#:   라벨 1,455건 실측에서 목표 격차 중앙이 부하별로 **13배** 벌어졌다:
#:       부하  3,500 →  2,999원 (목표 중앙 0.30 — 신호가 묻힌다)
#:            12,500 → 39,907원 (목표 중앙 3.99 — 학습이 튄다)
#:   학습률은 고정인데 목표가 13배 오르내리면 **부하 12,500 인 날의 갱신이 3,500 인
#:   날보다 13배 세게 민다.** 24회차 중 9회차가 눈금 경고를 냈고, 마지막 회차가 가장
#:   난폭했으며 그 직후 평가가 최악(+39.23%)이었다.
#:
#: 왜 정책이 안 망가지나 — **순서만 쓰기 때문이다.**
#:   `rank()` 는 점수를 크기순 비교에만 쓴다. 양수로 나누면 순서가 안 바뀌므로
#:   날마다 눈금이 달라도 **정책의 행동은 그대로**다. 바뀌는 것은 각 날이 기울기에
#:   기여하는 **세기**뿐이고, 그것을 고르게 만드는 것이 이 변경의 목적이다.
#:
#: 왜 하한이 필요한가 — 차이가 **정확히 0 인 결정이 약 21%** 다.
#:   중앙값이 0 에 가까워지면 나눗셈이 폭발한다. 그리고 하루 Φ 가 수천만~수십억인데
#:   격차 중앙이 1,000원 미만이면 그날 선택은 사실상 **비용 중립**이다 — 그것을
#:   목표 1 로 부풀리면 망이 **반올림 잡음을 쫓게** 된다. 하한이 그 증폭을 막는다.
#:   (실측 최솟값은 부하 3,500 의 921원 — 하한은 그 바로 위다.)
CRANE_SCALE_FLOOR = 1_000.0

#: WAIT 자리 — `BaselinePreference` 규약과 같다(항상 최하위).
_WAIT_KEY: tuple = (2, 0.0, "")


def float32_key(row):
    """Identity of the actual network input, including float32 rounding."""
    return struct.unpack(f'{len(row)}f', struct.pack(f'{len(row)}f', *row))


class CraneNet(nn.Module):
    """후보 하나 → 상대비용 하나. 재배정층 망과 같은 모양(2층 64 ReLU).

    같은 모양을 쓰는 이유는 **비교를 깨끗하게** 하기 위해서다 — 크레인 축의 효과를
    보려는 것이지 망 구조의 효과를 보려는 게 아니다.
    """

    def __init__(self, dim: int = CRANE_DIM, hidden: int = 64, *, feature_mode='legacy',
                 include_flow=False, count_transform='clipped'):
        super().__init__()
        if feature_mode not in ('legacy', 'feasible'):
            raise ValueError(f'unknown feature_mode: {feature_mode}')
        self.feature_mode = feature_mode
        if count_transform not in COUNT_TRANSFORMS:
            raise ValueError(f'unknown candidate count transform: {count_transform}')
        self.count_transform = count_transform
        self.include_flow = bool(include_flow)
        if self.include_flow and dim == CRANE_DIM:
            dim += 1
        if self.include_flow and dim != CRANE_DIM+1:
            raise ValueError('STORE input requires the ten-input model')
        self.net = nn.Sequential(
            nn.Linear(dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 1))

    def forward(self, x):
        return self.net(x).squeeze(-1)

    def model_config(self):
        return dict(dim=self.net[0].in_features, hidden=self.net[0].out_features,
                    feature_mode=self.feature_mode, include_flow=self.include_flow,
                    count_transform=self.count_transform)

    @classmethod
    def from_checkpoint(cls, checkpoint):
        state = checkpoint['crane']
        config = checkpoint.get('model_config', dict(
            dim=state['net.0.weight'].shape[1], hidden=state['net.0.weight'].shape[0],
            feature_mode=checkpoint.get('feature_mode','legacy'),
            include_flow=checkpoint.get('include_flow',False),
            count_transform=checkpoint.get('count_transform','clipped')))
        if config.get('architecture') in ('mean_context', 'star_attention'):
            from .context import ContextCraneNet
            net = ContextCraneNet(**config)
        else:
            net = cls(**config)
        net.load_state_dict(state)
        return net.eval()


def add_store_input(source):
    """One extra input, initial weight zero; all existing parameters copied."""
    if source.net[0].in_features != CRANE_DIM:
        raise ValueError('expected a nine-input source model')
    parameter = next(source.parameters())
    target = CraneNet(hidden=source.net[0].out_features, feature_mode=source.feature_mode,
                      include_flow=True, count_transform=source.count_transform).to(
                          device=parameter.device, dtype=parameter.dtype)
    state = source.state_dict()
    with torch.no_grad():
        for name, value in target.state_dict().items():
            if name == 'net.0.weight':
                value.zero_()
                value[:,:CRANE_DIM].copy_(state[name])
            else:
                value.copy_(state[name])
    return target.eval()


class CranePolicy(BaselinePreference):
    """학습 망으로 일감을 고르는 크레인 정책.

    `dispatch.make_preference` 가 만드는 규칙 바닥들과 **같은 자리에 꽂힌다**.
    """

    USES_FUTURE_INFORMATION = False       # 공개 정보만 본다 (계약)
    name = "RL_CRANE"

    def __init__(self, net: CraneNet | None = None, *, serve_first: bool = True,
                 batched: bool = True):
        self.net = net if net is not None else CraneNet()
        self.net.eval()
        #: ★실작업 우선 울타리 — 위 머리말의 [[YR-039]] 퇴화 방지.
        #:  끄면 망이 SERVE/PRE_REHANDLE/REPOSITION 을 완전히 자유롭게 고른다.
        #:  **효과가 실증되기 전에는 켜 둔다.**
        self.serve_first = bool(serve_first)
        self.batched = batched
        #: ★강제 손잡이 — `{크레인: job_id}`. 반사실 세계에서 *"대신 저걸 했다면"* 을
        #:  만드는 과거 대조군 손잡이다. 기본 교사는 아래 score_once를 쓴다.
        #:  판매·구매의 `force_once` 와 같은 규약이되,
        #:  **비우는 책임은 부르는 쪽**에 있다 (`crane/rollout.py` 가 결정 하나를
        #:  손으로 돌린 직후 비운다) — 시계로 맞추면 분기 시각이 결정 시각과
        #:  1e-6 만 어긋나도 강제가 통째로 날아간다.
        self.force_once: dict[str, str] = {}
        # Training-only score intervention. Unlike legacy force_once, it keeps
        # priority tiers and gives equal network inputs the same score.
        self.score_once: dict[tuple, float] = {}

    def rank(self, sim, crane_id, gc) -> tuple:
        if getattr(self.net, 'requires_candidate_context', False):
            raise ValueError('context policy requires rank_many with the full feasible candidate set')
        ref = gc.job_ref
        if ref is None:
            return _WAIT_KEY
        if self.force_once.get(crane_id) == ref.job_id:
            #: tier −1 — 어떤 후보보다도 앞. 단 resolver 가 `mandatory` 를 더 앞에
            #: 두므로 **필수 작업은 못 제친다**(엔진 계약). 강제가 실제로 먹었는지는
            #: 부르는 쪽이 결과를 읽어 확인한다.
            return (-1, 0.0, ref.job_id)
        x = crane_features(sim, crane_id, gc, feature_mode=getattr(self.net, 'feature_mode', 'legacy'),
                           include_flow=getattr(self.net, 'include_flow', False),
                           count_transform=getattr(self.net, 'count_transform', 'clipped'))
        with torch.no_grad():
            score = float(self.net(torch.tensor([x], dtype=torch.float32))[0])
        if self.score_once:
            score = self.score_once.get(float32_key(x), score)
        tier = 0 if (not self.serve_first or gc.kind == CandidateKind.SERVE) else 1
        #: `job_id` 를 끝에 두는 것은 **결정론**을 위해서다 — 점수가 같으면 항상 같은 배정.
        return (tier, score, ref.job_id)

    def rank_many(self, sim, pairs):
        """Per-decision values only: common features once, no global monkeypatch.

        Equal input vectors share computation. Distinct almost-tied vectors are
        rescored with the original scalar path to protect deterministic ordering.
        Subclasses overriding rank retain their own contract.
        """
        if getattr(self.net, 'requires_candidate_context', False):
            from .context import context_ranks
            return context_ranks(self, sim, pairs)
        if not self.batched or type(self).rank is not CranePolicy.rank:
            return [self.rank(sim, cid, gc) for cid, gc in pairs]
        common = decision_common(sim)
        rows, lookup, row_ids = [], {}, []
        keys = []
        for cid, gc in pairs:
            ref = gc.job_ref
            if ref is None:
                keys.append(_WAIT_KEY)
                row_ids.append(None)
                continue
            if self.force_once.get(cid) == ref.job_id:
                keys.append((-1, 0.0, ref.job_id))
                row_ids.append(None)
                continue
            row = tuple(crane_features(sim, cid, gc, common=common,
                                      feature_mode=getattr(self.net, 'feature_mode', 'legacy'),
                                      include_flow=getattr(self.net, 'include_flow', False),
                                      count_transform=getattr(self.net, 'count_transform', 'clipped')))
            if row not in lookup:
                lookup[row] = len(rows)
                rows.append(row)
            row_ids.append(lookup[row])
            tier = 0 if not self.serve_first or gc.kind == CandidateKind.SERVE else 1
            keys.append((tier, None, ref.job_id))
        values = []
        with torch.no_grad():
            for start in range(0, len(rows), 1024):
                values.extend(self.net(torch.tensor(rows[start:start+1024], dtype=torch.float32)).tolist())
            order = sorted(range(len(values)), key=values.__getitem__)
            close = set()
            for a, b in zip(order, order[1:]):
                if abs(values[a]-values[b]) <= 1e-6 + 1e-5*max(abs(values[a]), abs(values[b])):
                    close.update((a, b))
            for i in sorted(close):
                values[i] = float(self.net(torch.tensor([rows[i]], dtype=torch.float32))[0])
        if self.score_once:
            values = [self.score_once.get(float32_key(row), value)
                      for row, value in zip(rows, values)]
        return [key if i is None else (key[0], values[i], key[2])
                for key, i in zip(keys, row_ids)]


def to_advantage(phi: float, base: float, scale: float | None = None) -> float:
    """`(Φ − 그 결정의 기준선) / 눈금` — 학습 목표.

    기준선은 그 결정에서 굴린 세계들의 평균이다. 양쪽에서 같은 값을 빼므로
    **argmin 순서는 안 바뀐다**(상수 차감). 재배정층 `nets.to_advantage` 와 같은 규약.

    `scale` — 안 주면 `CRANE_ADV_SCALE`. 학습 경로는 **그날 라벨의 중앙 격차**를
    넣는다 ([[YR-309]] · `CraneLabelCollector.result` 가 계산해 넘긴다).
    """
    return (float(phi) - float(base)) / float(scale or CRANE_ADV_SCALE)


def from_advantage(x: float, scale: float | None = None) -> float:
    """망 출력 → 원화 (기준선 대비). 보고·진단용. 눈금은 `to_advantage` 와 같아야 한다."""
    return float(x) * float(scale or CRANE_ADV_SCALE)
